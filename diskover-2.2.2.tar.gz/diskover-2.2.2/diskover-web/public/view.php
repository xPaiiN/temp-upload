<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
use Elasticsearch\Common\Exceptions\Missing404Exception;
require "../src/diskover/Auth.php";
require "../src/diskover/Diskover.php";


$message = $_REQUEST['message'];

// Check if file ID was provided
if (empty($_REQUEST['id'])) {
    handleError('ES doc id not found');
} else {
    // Try to get file info from from index
    try {
        $searchParams = [];
        $searchParams['index'] = $_REQUEST['docindex'];
        $searchParams['body'] = [
            'query' => [
                'ids' => [
                    'values' => [$_REQUEST['id']]
                ]
            ]
        ];
        $queryResponse = $client->search($searchParams);

        $docid = $queryResponse['hits']['hits'][0]['_id'];
        $docindex = $queryResponse['hits']['hits'][0]['_index'];
        $docsource = $queryResponse['hits']['hits'][0]['_source'];
        $doctype = $docsource['type'];
    } catch (Missing404Exception $e) {
        handleError('ES error: ' . $e->getMessage());
    } catch (Exception $e) {
        handleError('ES error: ' . $e->getMessage());
    }

    // set fullpath, parentpath and filename and check for root /
    $parentpath = $docsource['parent_path'];
    $parentpath_wildcard = escape_chars($parentpath) . '\/*';
    if ($parentpath === "/") {
        if ($docsource['name'] === "") { // root /
            $filename = '/';
            $fullpath = '/';
            $fullpath_wildcard = '\/*';
        } else {
            $filename = $docsource['name'];
            $fullpath = '/' . $filename;
            $fullpath_wildcard = escape_chars($fullpath) . '\/*';
            $parentpath_wildcard = '\/*';
        }
    } else {
        $fullpath = $parentpath . '/' . $docsource['name'];
        $filename = $docsource['name'];
        $fullpath_wildcard = escape_chars($fullpath) . '\/*';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());

            gtag('config', 'G-NDFBQ1BYMH');
        </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; File View</title>
    <link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="css/diskover.css" media="screen" />
    <link rel="icon" type="image/png" href="images/diskoverfavico.png" />
</head>

<body>
    <?php include "nav.php"; ?>
    <div class="container" style="margin-top:70px">
        <div class="well well-lg">
            <div class="row">
                <div class="col-xs-12">
                    <?php
                    if ($doctype == 'directory') {
                        $fullpathhref = "search.php?index=" . $esIndex . "&index2=" . $esIndex2 . "&submitted=true&p=1&q=parent_path:" . rawurlencode(escape_chars($fullpath)) . "&path=" . rawurlencode($fullpath);
                    } else {
                        $fullpathhref = "search.php?index=" . $esIndex . "&index2=" . $esIndex2 . "&submitted=true&p=1&q=parent_path:" . rawurlencode(escape_chars($parentpath)) . " AND name:&quot;" . rawurlencode(escape_chars($filename)) . "&quot;&path=" . rawurlencode($parentpath);
                    }
                    ?>
                    <h2 class="path"><?php echo ($doctype == 'file') ? '<i class="fas fa-file-alt" style="color:#738291;"></i>' : '<i class="fas fa-folder" style="color:#E9AC47;"></i>'; ?> <span id="filename"><a href="<?php echo $fullpathhref; ?>" target="_blank"><?php echo $filename; ?></a></span></h2>
                    <div style="padding-bottom:10px"><a href="#" class="btn btn-default btn-xs file-btns" onclick="copyToClipboard('#filename')"><i class="glyphicon glyphicon-copy"></i> Copy file name</a></div>
                    <!-- tag dropdown -->
                    <div class="dropdown" style="display:inline-block;">
                        <form id="changetag" name="changetag" class="form-inline">
                            <input type="hidden" name="id" value="<?php echo $docid; ?>">
                            <input type="hidden" name="doctype" value="<?php echo $doctype; ?>">
                            <input type="hidden" name="docindex" value="<?php echo $docindex; ?>">
                            <input type="hidden" name="tag" value="" id="tag">
                            <input type="hidden" name="newtagtext" value="" id="newtagtext">
                            <div class="dropdown">
                                <button title="tag" class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown"><i class="glyphicon glyphicon-tag"></i> Tag <?php if ($_SESSION['license']['product_code'] == 'ESS') { echo '<span class="label label-info">Pro</span>'; } ?>
                                    <span class="caret"></span></button>
                                <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                                    <ul class="dropdown-menu multi-level" role="menu">
                                        <li><a href="#">Pro version required</a></li>
                                    </ul>
                                    </form>
                                <?php } else { ?>
                                <ul class="dropdown-menu multi-level" role="menu">
                                    <?php foreach ($customtags as $key => $value) { ?>
                                        <li onclick="$('#tag').val('<?php echo $value[0]; ?>'); ajaxTagFiles()"><a href="#"><i class="glyphicon glyphicon-tag" style="color:<?php echo $value[1]; ?>"></i> <span style="color:<?php echo $value[1]; ?>"><?php echo $value[0]; ?></span></a></li>
                                    <?php } ?>
                                    <li class="divider"></li>
                                    <li onclick="$('#tag').val('null'); ajaxTagFiles()"><a href="#"><span class="text-primary"><i class="glyphicon glyphicon-remove"></i> Remove all tags</span></a></li>
                                    <li class="divider"></li>
                                    <li>
                                        <?php echo (!$adminuser) ? "<span style=\"margin:0px;padding:0px;margin-left:10px;font-size:11px;color:white;\"><i class=\"fas fa-users-cog\"></i> <i><b>Admin user required</b></i></span><br>" : "" ?>
                                        <input type="text" name="tagtext" id="tagtext" class="form-control input input-sm" style="margin-left:6px; width:75%;" value="" placeholder="Add new..." <?php echo (!$adminuser) ? "disabled" : "" ?>>
                                        <button class="btn btn-default btn-xs" onclick="$('#newtagtext').val(document.getElementById('tagtext').value); ajaxTagFiles()" type="submit" <?php echo (!$adminuser) ? "disabled" : "" ?>> <i class="glyphicon glyphicon-plus small"></i></button><br />
                                        <span style="margin:0px;padding:0px;margin-left:10px;font-size:11px;color:darkgray;">tag name|#hexcolor</span>
                                    </li>
                                    <?php if ($doctype == 'directory') { ?>
                                        <li class="divider"></li>
                                        <li class="dropdown-submenu">
                                            <a href="#"><span class="text-primary"><i class="fas fa-folder"></i> Apply tags to</span></a>
                                            <ul class="dropdown-menu">
                                                <li onclick="$('#tag').val('tagall_subdirs_norecurs'); ajaxTagFiles()"><a href="#"><span class="text-primary">Subdirs (non-recursive)</span></a></li>
                                                <li onclick="$('#tag').val('tagall_files_norecurs'); ajaxTagFiles()"><a href="#"><span class="text-primary">Files (non-recursive)</span></a></li>
                                                <li onclick="$('#tag').val('tagall_all_norecurs'); ajaxTagFiles()"><a href="#"><span class="text-primary">All (non-recursive)</span></a></li>
                                                <li onclick="$('#tag').val('tagall_subdirs_recurs'); ajaxTagFiles()"><a href="#"><span class="text-primary">Subdirs (recursive)</span></a></li>
                                                <li onclick="$('#tag').val('tagall_files_recurs'); ajaxTagFiles()"><a href="#"><span class="text-primary">Files (recursive)</span></a></li>
                                                <li onclick="$('#tag').val('tagall_all_recurs'); ajaxTagFiles()"><a href="#"><span class="text-primary">All (recursive)</span></a></li>
                                            </ul>
                                        </li>
                                    <?php } ?>
                        </form>
                        <li class="divider"></li>
                        <li><a href="edittags.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>" target="_blank"><span class="text-primary"><i class="glyphicon glyphicon-edit"></i> Edit tags</span></a></li>
                        </ul>
                        <!-- end tag dropdown -->
                        <!-- tags -->
                        <?php if ($_SESSION['license']['product_code'] !== 'ESS') { ?>
                        <span style="padding-left:10px; font-size:16px; display:inline-block">
                            <?php
                            $tag_arr = $docsource['tags'];
                            if ($tag_arr) {
                                $tags = "";
                                foreach ($tag_arr as $key => $val) {
                                    if (empty($val)) {
                                        continue;
                                    }
                                    $color = get_custom_tag_color($val);
                                    $tags .= "<a style=\"text-decoration:none;\" href=\"search.php?submitted=true&p=1&q=tags:&quot;" . urlencode($val) . "&quot;\"><span title=\"" . $val . "\" style=\"margin-right:10px; color:" . $color . "\"><i class=\"glyphicon glyphicon-tag\"></i> " . $val . "</span></a>";
                                }
                                echo $tags;
                            }
                            ?>
                        </span>
                        <?php } } ?>
                    </div>
                    <!-- end tags -->
                    <!-- file action button -->
                    <div class="btn-group" style="display:inline-block; margin-top:10px">
                        <button title="file action" id="fileactionbutton" class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown"><i class="fas fa-cogs"></i> File Action <?php if ($_SESSION['license']['product_code'] == 'ESS') { echo '<span class="label label-info">Pro</span>'; } ?>
                            <span class="caret"></span></button>
                        <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                        <ul class="dropdown-menu">
                            <li><a href="#">Pro version required</a></li>
                        </ul>
                        <?php } else { ?>
                        <ul class="dropdown-menu">
                            <?php
                            if (empty($config->FILE_ACTIONS)) {
                                echo "<li><a href=\"#\">No file actions</a></li>";
                            } else {
                                foreach ($config->FILE_ACTIONS as $actionname => $actionval) {
                                    if (!empty($actionval['menu_icon_class'])) {
                                        $fa_icon = '<i class="' . $actionval['menu_icon_class'] . '"></i>';
                                    } else {
                                        $fa_icon = '<i class="fas fa-cog"></i>';
                                    }
                            ?>
                                    <li><a href="fileactions/<?php echo $actionval['webpage'] ?>?docid=<?php echo $_REQUEST['id'] ?>&docindex=<?php echo $_REQUEST['docindex'] ?>" target="_blank"><?php echo $fa_icon . " " . $actionname ?></a></li>
                            <?php }
                            } ?>
                        </ul>
                        <?php } ?>
                    </div>
                    <!-- end file action button -->
                    <h5 class="path">Full path: <span id="fullpath"><a href="<?php echo $fullpathhref; ?>" target="_blank"><?php echo $fullpath; ?></a></span></h5> <a href="#" class="btn btn-default btn-xs file-btns" onclick="copyToClipboard('#fullpath')"><i class="glyphicon glyphicon-copy"></i> Copy path</a>
                    <?php if ($_REQUEST['doctype'] == 'directory') { ?>
                        <div class="dropdown" style="display:inline-block;">
                            <button title="analytics" class="btn btn-default dropdown-toggle btn-xs file-btns" type="button" data-toggle="dropdown"><i class="glyphicon glyphicon-stats"></i>
                                <span class="caret"></span></button>
                            <ul class="dropdown-menu">
                                <li class="small"><a href="filetree.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($fullpath); ?>&amp;filter=<?php echo $_COOKIE['filter']; ?>&amp;time=<?php echo $_COOKIE['time']; ?>&amp;use_count=<?php echo $_COOKIE['use_count']; ?>&amp;show_files=<?php echo $_COOKIE['show_files']; ?>" target="_blank"><i class="glyphicon glyphicon-tree-conifer"></i> load path in file tree</a></li>
                                <li class="small"><a href="treemap.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($fullpath); ?>&amp;filter=<?php echo $_COOKIE['filter']; ?>&amp;time=<?php echo $_COOKIE['time']; ?>&amp;maxdepth=<?php echo $_COOKIE['maxdepth']; ?>&amp;use_count=<?php echo $_COOKIE['use_count']; ?>&amp;show_files=<?php echo $_COOKIE['show_files']; ?>" target="_blank"><i class="glyphicon glyphicon-th-large"></i> load path in treemap</a></li>
                                <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                                <li class="small"><a href="#"><i class="glyphicon glyphicon-fire"></i> load path in heatmap <span class="label label-info">Pro</span></a></li>
                                <?php } else { ?>
                                <li class="small"><a href="heatmap.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($fullpath); ?>&amp;filter=<?php echo $_COOKIE['filter']; ?>&amp;time=<?php echo $_COOKIE['time']; ?>&amp;maxdepth=<?php echo $_COOKIE['maxdepth']; ?>&amp;use_count=<?php echo $_COOKIE['use_count']; ?>&amp;show_files=<?php echo $_COOKIE['show_files']; ?>&amp;show_new_dirs=<?php echo $_COOKIE['show_new_dirs']; ?>" target="_blank"><i class="glyphicon glyphicon-fire"></i> load path in heatmap</a></li>
                                <?php } ?>
                                <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                                <li class="small"><a href="#"><i class="glyphicon glyphicon-tags"></i> load path in tags <span class="label label-info">Pro</span></a></li>
                                <?php } else { ?>
                                <li class="small"><a href="tags.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($fullpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-tags"></i> load path in tags</a></li>
                                <?php } ?>
                                <li class="small"><a href="smartsearches.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($fullpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-equalizer"></i> load path in smart searches</a></li>
                                <li class="small"><a href="useranalysis.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($fullpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-user"></i> load path in user analysis</a></li>
                                <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                                <li class="small"><a href="#"><i class="glyphicon glyphicon-piggy-bank"></i> load path in cost analysis <span class="label label-info">Pro</span></a></li>
                                <?php } else { ?>
                                <li class="small"><a href="costanalysis.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($fullpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-piggy-bank"></i> load path in cost analysis</a></li>
                                <?php } ?>
                                <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                                <li class="small"><a href="#"><i class="glyphicon glyphicon-stats"></i> load path in reports <span class="label label-info">Pro</span></a></li>
                                <?php } else { ?>
                                <li class="small"><a href="reports.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($fullpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-stats"></i> load path in reports</a></li>
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="dropdown" style="display:inline-block;">
                            <button title="search" class="btn btn-default dropdown-toggle btn-xs file-btns" type="button" data-toggle="dropdown"><i class="glyphicon glyphicon-search"></i>
                                <span class="caret"></span></button>
                            <ul class="dropdown-menu">
                                <li class="small"><a href="search.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;submitted=true&amp;p=1&amp;q=parent_path:<?php echo rawurlencode(escape_chars($fullpath)); ?>" target="_blank"><i class="glyphicon glyphicon-search"></i> search path (non-recursive)</a></li>
                                <li class="small"><a href="search.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;submitted=true&amp;p=1&amp;q=parent_path:(<?php echo rawurlencode(escape_chars($fullpath)) . ' OR ' . rawurlencode($fullpath_wildcard); ?>)" target="_blank"><i class="glyphicon glyphicon-search"></i> search path (recursive)</a></li>
                            </ul>
                        </div>
                        <br />
                    <?php } ?>
                    <h5 class="path"><i class="fas fa-folder" style="color:#E9AC47;"></i> <span style="color:gray">Parent path: <span id="parentpath"><a href="search.php?submitted=true&p=1&q=parent_path:<?php echo rawurlencode(escape_chars($parentpath)); ?>&path=<?php echo rawurlencode($parentpath); ?>" target="_blank"><?php echo $parentpath; ?></a></span> </span></h5> <a href="#" class="btn btn-default btn-xs file-btns" onclick="copyToClipboard('#parentpath')"><i class="glyphicon glyphicon-copy"></i> Copy path</a>
                    <div class="dropdown" style="display:inline-block;">
                        <button title="analytics" class="btn btn-default dropdown-toggle btn-xs file-btns" type="button" data-toggle="dropdown"><i class="glyphicon glyphicon-stats"></i>
                            <span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li class="small"><a href="filetree.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($parentpath); ?>&amp;filter=<?php echo $_COOKIE['filter']; ?>&amp;time=<?php echo $_COOKIE['time']; ?>&amp;use_count=<?php echo $_COOKIE['use_count']; ?>&amp;show_files=<?php echo $_COOKIE['show_files']; ?>" target="_blank"><i class="glyphicon glyphicon-tree-conifer"></i> load path in file tree</a></li>
                            <li class="small"><a href="treemap.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($parentpath); ?>&amp;filter=<?php echo $_COOKIE['filter']; ?>&amp;time=<?php echo $_COOKIE['time']; ?>&amp;maxdepth=<?php echo $_COOKIE['maxdepth']; ?>&amp;use_count=<?php echo $_COOKIE['use_count']; ?>&amp;show_files=<?php echo $_COOKIE['show_files']; ?>" target="_blank"><i class="glyphicon glyphicon-th-large"></i> load path in treemap</a></li>
                            <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                            <li class="small"><a href="#"><i class="glyphicon glyphicon-fire"></i> load path in heatmap <span class="label label-info">Pro</span></a></li>
                            <?php } else { ?>
                            <li class="small"><a href="heatmap.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($parentpath); ?>&amp;filter=<?php echo $_COOKIE['filter']; ?>&amp;time=<?php echo $_COOKIE['time']; ?>&amp;maxdepth=<?php echo $_COOKIE['maxdepth']; ?>&amp;use_count=<?php echo $_COOKIE['use_count']; ?>&amp;show_files=<?php echo $_COOKIE['show_files']; ?>&amp;show_new_dirs=<?php echo $_COOKIE['show_new_dirs']; ?>" target="_blank"><i class="glyphicon glyphicon-fire"></i> load path in heatmap</a></li>
                            <?php } ?>
                            <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                            <li class="small"><a href="#"><i class="glyphicon glyphicon-tags"></i> load path in tags <span class="label label-info">Pro</span></a></li>
                            <?php } else { ?>
                            <li class="small"><a href="tags.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($parentpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-tags"></i> load path in tags</a></li>
                            <?php } ?>
                            <li class="small"><a href="smartsearches.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($parentpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-equalizer"></i> load path in smart searches</a></li>
                            <li class="small"><a href="useranalysis.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($parentpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-user"></i> load path in user analysis</a></li>
                            <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                            <li class="small"><a href="#"><i class="glyphicon glyphicon-piggy-bank"></i> load path in cost analysis <span class="label label-info">Pro</span></a></li>
                            <?php } else { ?>
                            <li class="small"><a href="costanalysis.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($parentpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-piggy-bank"></i> load path in cost analysis</a></li>
                            <?php } ?>
                            <?php if ($_SESSION['license']['product_code'] == 'ESS') { ?>
                            <li class="small"><a href="#"><i class="glyphicon glyphicon-stats"></i> load path in reports <span class="label label-info">Pro</span></a></li>
                            <?php } else { ?>
                            <li class="small"><a href="reports.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;path=<?php echo rawurlencode($parentpath); ?>&amp;togglecurrentdir=showcurrentdir&amp;toggletoppath=" target="_blank"><i class="glyphicon glyphicon-stats"></i> load path in reports</a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <div class="dropdown" style="display:inline-block;">
                        <button title="filter" class="btn btn-default dropdown-toggle btn-xs file-btns" type="button" data-toggle="dropdown"><i class="glyphicon glyphicon-search"></i>
                            <span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li class="small"><a href="search.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;submitted=true&amp;p=1&amp;q=parent_path:<?php echo rawurlencode(escape_chars($parentpath)); ?>" target="_blank"><i class="glyphicon glyphicon-search"></i> search path (non-recursive)</a></li>
                            <li class="small"><a href="search.php?index=<?php echo $esIndex; ?>&amp;index2=<?php echo $esIndex2; ?>&amp;submitted=true&amp;p=1&amp;q=parent_path:(<?php echo rawurlencode(escape_chars($parentpath)) . ' OR ' . rawurlencode($parentpath_wildcard); ?>)" target="_blank"><i class="glyphicon glyphicon-search"></i> search path (recursive)</a></li>
                        </ul>
                    </div>
                    <br /><br />
                </div>
            </div>
            <div class="row">
                <div class="col-xs-6">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <span class="pull-right">&nbsp;
                                <!-- show comparison file size -->
                                <?php if ($esIndex2 != "") { ?>
                                    <?php $fileinfo_index2 = get_index2_fileinfo($client, $esIndex2, $docsource['parent_path'], $docsource['name']);
                                    if ($docsource['size'] > 0 && $fileinfo_index2[0] > 0) {
                                        $filesize_change = number_format(changePercent($docsource['size'], $fileinfo_index2[0]), 1);
                                    } else if ($docsource['size'] > 0 && $fileinfo_index2[0] == 0) {
                                        $filesize_change = 100.0;
                                    }
                                    if ($filesize_change != 0) { ?>
                                        <small><?php echo formatBytes($fileinfo_index2[0]); ?>
                                            <span style="color:<?php echo $filesize_change > 0 ? "red" : "#29FE2F"; ?>;">(<?php echo $filesize_change > 0 ? '<i class="fa fa-caret-up"></i> +' : '<i class="fa fa-caret-down"></i>'; ?>
                                                <?php echo $filesize_change; ?>%)</span></small>
                                <?php }
                                } ?>
                                <!-- end show comparison file size -->
                            </span>
                            <span class="badge"><?php echo formatBytes($docsource['size']); ?></span>
                            Size
                        </li>
                        <li class="list-group-item">
                            <span class="pull-right">&nbsp;
                                <!-- show comparison file size -->
                                <?php if ($esIndex2 != "") { ?>
                                    <?php
                                    if ($docsource['size_du'] > 0 && $fileinfo_index2[1] > 0) {
                                        $filesizedu_change = number_format(changePercent($docsource['size_du'], $fileinfo_index2[1]), 1);
                                    } else if ($docsource['size_du'] > 0 && $fileinfo_index2[0] == 0) {
                                        $filesizedu_change = 100.0;
                                    }
                                    if ($filesizedu_change != 0) { ?>
                                        <small><?php echo formatBytes($fileinfo_index2[1]); ?>
                                            <span style="color:<?php echo $filesizedu_change > 0 ? "red" : "#29FE2F"; ?>;">(<?php echo $filesizedu_change > 0 ? '<i class="fa fa-caret-up"></i> +' : '<i class="fa fa-caret-down"></i>'; ?>
                                                <?php echo $filesizedu_change; ?>%)</span></small>
                                <?php }
                                } ?>
                                <!-- end show comparison file size -->
                            </span>
                            <span class="badge"><?php echo formatBytes($docsource['size_du']); ?></span>
                            Allocated
                        </li>
                        <?php if ($_REQUEST['doctype'] == 'directory') {
                            $items = $docsource['file_count'] + $docsource['dir_count'];
                        ?>
                            <li class="list-group-item">
                                <span class="pull-right">&nbsp;
                                    <!-- show comparison items -->
                                    <?php if ($esIndex2 != "") { ?>
                                        <?php
                                        if ($items > 0 && $fileinfo_index2[2] > 0) {
                                            $diritems_change = number_format(changePercent($items, $fileinfo_index2[2]), 1);
                                        } else if ($items > 0 && $fileinfo_index2[2] == 0) {
                                            $diritems_change = 100.0;
                                        }
                                        if ($diritems_change != 0) { ?>
                                            <small><?php echo number_format($fileinfo_index2[2]); ?>
                                                <span style="color:<?php echo $diritems_change > 0 ? "red" : "#29FE2F"; ?>;">(<?php echo $diritems_change > 0 ? '<i class="fa fa-caret-up"></i> +' : '<i class="fa fa-caret-down"></i>'; ?>
                                                    <?php echo $diritems_change; ?>%)</span></small>
                                    <?php }
                                    } ?>
                                    <!-- end show comparison items -->
                                </span>
                                <span class="badge"><?php echo number_format($items); ?></span>
                                Items
                            </li>
                            <li class="list-group-item">
                                <span class="pull-right">&nbsp;
                                    <!-- show comparison items -->
                                    <?php if ($esIndex2 != "") { ?>
                                        <?php
                                        if ($docsource['file_count'] > 0 && $fileinfo_index2[3] > 0) {
                                            $diritems_files_change = number_format(changePercent($docsource['file_count'], $fileinfo_index2[3]), 1);
                                        } else if ($docsource['file_count'] > 0 && $fileinfo_index2[3] == 0) {
                                            $diritems_files_change = 100.0;
                                        }
                                        if ($diritems_files_change != 0) { ?>
                                            <small><?php echo number_format($fileinfo_index2[3]); ?>
                                                <span style="color:<?php echo $diritems_files_change > 0 ? "red" : "#29FE2F"; ?>;">(<?php echo $diritems_files_change > 0 ? '<i class="fa fa-caret-up"></i> +' : '<i class="fa fa-caret-down"></i>'; ?>
                                                    <?php echo $diritems_files_change; ?>%)</span></small>
                                    <?php }
                                    } ?>
                                    <!-- end show comparison items -->
                                </span>
                                <span class="badge"><?php echo number_format($docsource['file_count']); ?></span>
                                Files
                            </li>
                            <li class="list-group-item">
                                <span class="pull-right">&nbsp;
                                    <!-- show comparison items -->
                                    <?php if ($esIndex2 != "") { ?>
                                        <?php
                                        if ($docsource['dir_count'] > 0 && $fileinfo_index2[4] > 0) {
                                            $diritems_subdirs_change = number_format(changePercent($docsource['dir_count'], $fileinfo_index2[4]), 1);
                                        } else if ($docsource['dir_count'] > 0 && $fileinfo_index2[4] == 0) {
                                            $diritems_subdirs_change = 100.0;
                                        }
                                        if ($diritems_subdirs_change != 0) { ?>
                                            <small><?php echo number_format($fileinfo_index2[4]); ?>
                                                <span style="color:<?php echo $diritems_subdirs_change > 0 ? "red" : "#29FE2F"; ?>;">(<?php echo $diritems_subdirs_change > 0 ? '<i class="fa fa-caret-up"></i> +' : '<i class="fa fa-caret-down"></i>'; ?>
                                                    <?php echo $diritems_subdirs_change; ?>%)</span></small>
                                    <?php }
                                    } ?>
                                    <!-- end show comparison items -->
                                </span>
                                <span class="badge"><?php echo number_format($docsource['dir_count']); ?></span>
                                Folders
                            </li>
                        <?php } ?>
                        <?php if ($_REQUEST['doctype'] == 'file') { ?>
                            <li class="list-group-item">
                                <span class="badge"><?php echo $docsource['extension']; ?></span>
                                <a href="search.php?submitted=true&amp;p=1&amp;q=extension:<?php echo $docsource['extension']; ?>&amp;doctype=<?php echo $_REQUEST['doctype']; ?>" target="_blank">Extension</a>
                            </li>
                        <?php } ?>
                        <li class="list-group-item">
                            <span class="badge"><?php echo $docsource['owner']; ?></span>
                            <a href="search.php?submitted=true&amp;p=1&amp;q=owner:<?php echo $docsource['owner']; ?>&amp;doctype=<?php echo $_REQUEST['doctype']; ?>" target="_blank">Owner</a>
                        </li>
                        <li class="list-group-item">
                            <span class="badge"><?php echo $docsource['group']; ?></span>
                            <a href="search.php?submitted=true&amp;p=1&amp;q=group:<?php echo $docsource['group']; ?>&amp;doctype=<?php echo $_REQUEST['doctype']; ?>" target="_blank">Group</a>
                        </li>
                        <li class="list-group-item">
                            <span class="badge"><?php echo $docsource['ino']; ?></span>
                            <a href="search.php?submitted=true&amp;p=1&amp;q=ino:<?php echo $docsource['ino']; ?>&amp;doctype=<?php echo $_REQUEST['doctype']; ?>" target="_blank">Inode</a>
                        </li>
                        <li class="list-group-item">
                            <span class="badge"><?php echo $docsource['nlink']; ?></span>
                            Hardlinks
                        </li>
                    </ul>
                    <?php if ($showcostpergb) { ?>
                        <ul class="list-group">
                            <li class="list-group-item">
                                <span class="badge">$ <?php echo number_format(round($docsource['costpergb'], 2), 2); ?></span>
                                Cost per GB
                            </li>
                        </ul>
                    <?php } ?>
                </div>
                <div class="col-xs-6">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <span class="badge"><?php echo utcTimeToLocal($docsource['mtime']); ?></span>
                            Date modified
                        </li>
                        <li class="list-group-item">
                            <span class="badge"><?php echo utcTimeToLocal($docsource['atime']); ?></span>
                            Last accessed
                        </li>
                        <li class="list-group-item">
                            <span class="badge"><?php echo utcTimeToLocal($docsource['ctime']); ?></span>
                            Last changed
                        </li>
                    </ul>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <span class="badge"><?php echo $docindex; ?></span>
                            <a href="search.php?submitted=true&amp;p=1&amp;q=_index:<?php echo $docindex; ?>" target="_blank">Index name</a>
                        </li>
                    </ul>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <span class="badge"><?php echo $docid; ?></span>
                            <a href="search.php?submitted=true&amp;p=1&amp;q=_id:<?php echo $docid; ?>" target="_blank">Doc id</a>
                        </li>
                    </ul>
                </div>
            </div>
            <?php if (count($config->EXTRA_FIELDS) > 0) { ?>
            <div class="row">
                <div class="col-xs-12">
                    <h4>Extra fields</h4>
                    <ul class="list-group">
                        <?php foreach ($config->EXTRA_FIELDS as $key => $value) {
                                // media edition media info check
                                if ($value == 'media_info' && $_SESSION['license']['product_code'] !== 'ME') {
                                    echo '<li class="list-group-item">';
                                    echo '<p class="list-group-item-text">' . $key . ' <span class="label label-info">Media Edtion</span></p>';
                                    echo '</li>';
                                    continue;
                                }
                                // check if field empty
                                if (empty($docsource[$value])) {
                                    echo '<li class="list-group-item">';
                                    echo '<p class="list-group-item-text">No ' . $key . ' in doc</p>';
                                    echo '</li>';
                                    continue;
                                }
                                // check if object field type
                                if (is_array($docsource[$value])) { ?>
                                    <li class="list-group-item">
                                        <h5 class="list-group-item-heading"><?php echo $key; ?></h5>
                                        <?php foreach ($docsource[$value] as $k => $v) {
                                            if (is_array($v)) {
                                                foreach ($v as $v_key => $v_val) {
                                                    if (is_array($v_val)) {
                                                        foreach ($v_val as $v2_key => $v2_val) {
                                                            if (is_bool($v2_val)) {
                                                                $v2_val = ($v2_val) ? 'true' : 'false';
                                                            } ?>
                                                            <p class="list-group-item-text extrafields"><a href="search.php?submitted=true&amp;p=1&amp;q=<?php echo $value . '.' . $k . '.' . $v2_key . ': &quot;' . $v2_val; ?>&quot;&amp;doctype=<?php echo $_REQUEST['doctype']; ?>" target="_blank"><?php echo $value . '.' . $k . '.' . $v2_key . ': <strong>' . $v2_val . '</strong>'; ?></a></p>
                                                    <?php }
                                                    } else {
                                                        if (is_bool($v_val)) {
                                                            $v_val = ($v_val) ? 'true' : 'false';
                                                        } ?>
                                                        <p class="list-group-item-text extrafields"><a href="search.php?submitted=true&amp;p=1&amp;q=<?php echo $value . '.' . $k . '.' . $v_key . ': &quot;' . $v_val; ?>&quot;&amp;doctype=<?php echo $_REQUEST['doctype']; ?>" target="_blank"><?php echo $value . '.' . $k . '.' . $v_key . ': <strong>' . $v_val . '</strong>'; ?></a></p>
                                                <?php } }
                                            } else {
                                                if (is_bool($v)) {
                                                    $v = ($v) ? 'true' : 'false';
                                                } 
                                                $ef_string = $value . '.' . $k . ': <strong>' . $v . '</strong>';
                                                ?>
                                                <p class="list-group-item-text extrafields"><a href="search.php?submitted=true&amp;p=1&amp;q=<?php echo $value . '.' . $k . ': &quot;' . $v; ?>&quot;&amp;doctype=<?php echo $_REQUEST['doctype']; ?>" target="_blank"><?php echo $ef_string; ?></a></p>
                                        <?php }
                                        } ?>
                                    </li>
                                <?php } else { 
                                    # bool field like is_dupe
                                    if (is_bool($docsource[$value])) {
                                        $docsource[$value] = ($docsource[$value]) ? 'true' : 'false';
                                    }
                                    ?>
                                    <li class="list-group-item">
                                        <h5 class="list-group-item-heading"><?php echo $key; ?></h5>
                                        <p class="list-group-item-text extrafields"><a href="search.php?submitted=true&amp;p=1&amp;q=<?php echo $value .':&quot;' . $docsource[$value]; ?>&quot;&amp;doctype=<?php echo $_REQUEST['doctype']; ?>" target="_blank"><?php echo $value . ': <strong>' . $docsource[$value] . '</strong>'; ?></a></p>
                                    </li>
                        <?php } } ?>
                    </ul>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <?php include 'modals.php' ?>
    <script language="javascript" src="js/jquery.min.js"></script>
    <script language="javascript" src="js/bootstrap.min.js"></script>
    <script language="javascript" src="js/diskover.js"></script>
</body>

</html>