<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../vendor/autoload.php';
require "../../src/diskover/Auth.php";
require "../../src/diskover/Diskover.php";
require "tasks_inc.php";

if (!isset($_GET['name']) || !isset($_GET['action'])) exit;

$workername = $_GET['name'];
$action = $_GET['action'];

// read workers json file
$filename = "workers.json";
$file = fopen($filename, 'r');
lockFile($file, $filename);
$workers_json = readTasksFile($filename);
$workers_arr = json_decode($workers_json, true);
$workers = $workers_arr['workers'];
$newworkers = ['workers' => []];

// update workers json file
foreach ($workers as $worker) {
    if ($workername === $worker['name']) {
        if ($action === 'remove') {
            continue;
        } elseif ($action === 'disable') {
            $worker['disabled'] = true;
        } elseif ($action === 'enable') {
            $worker['disabled'] = false;
        }
    }
    $newworkers['workers'][] = $worker;
}

$workers_json = json_encode($newworkers, JSON_PRETTY_PRINT);
unlockFile($file);

writeToTasksFile($filename, $workers_json);

header('Location: tasks_workers.php');
exit;

?>