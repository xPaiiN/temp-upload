<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../../src/diskover/config_inc.php';

// check task panel user is logged in
if ($config->LOGIN_REQUIRED) {
    if (!$taskpaneluser) {
        echo '<script>alert("Task panel user required"); window.history.back();</script>';
        exit();
    }
}

function readTasksFile($filename)
{
    if (!is_readable($filename)) {
        handleError("File " . $filename . " does not exist or is not readable");
    }
    $data = file_get_contents($filename);
    if (is_bool($data) && $data === FALSE) {
        handleError('Error reading ' . $filename);
    }
    if (is_string($data) && $data === '') {
        handleError('Error ' . $filename . ' is empty');
    }
    return $data;
}

function writeToTasksFile($filename, $jsondata)
{
    if (!is_writable($filename)) {
        handleError('Error ' . $filename . ' does not exist or is not writable');
    }
    $res = file_put_contents($filename, $jsondata);
    if (is_bool($res) && $res === FALSE) {
        handleError('Error writing to file ' . $filename);
    }
    if (is_int($res) && $res === 0) {
        handleError('Error no data written to file ' . $filename);
    }
}

function lockFile($file, $filename)
{
    $lock = flock($file, LOCK_SH);
    if (!$lock) {
        handleError('Error could not lock file ' . $filename);
    }
}

function unlockFile($file)
{
    flock($file, LOCK_UN);
    fclose($file);
}