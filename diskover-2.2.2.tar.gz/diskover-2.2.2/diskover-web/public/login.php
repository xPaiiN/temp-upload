<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

ini_set('session.gc_maxlifetime', 604800);
ini_set("session.cookie_lifetime", 604800);
session_set_cookie_params(604800, "/");
ob_start();
session_start();
require '../vendor/autoload.php';
require '../src/diskover/version.php';
require "../src/diskover/config_inc.php";
require "../src/diskover/license_inc.php";

// Oauth2 OIDC SSO
if ($config->OAUTH2_LOGINS && (isset($_GET['ssosignin']) || isset($_GET['callback']))) {
   require "../src/diskover/Oauth.php";

   if (isset($_GET['callback'])) {
      authorization_code_callback_handler();
   }

   if (empty($_SESSION['oauth2_id_token'])) {
      start_oauth_flow();
   } else {
      login();
   }
   exit;
}

use diskover\Login;

// LDAP DEBUG
$ldapdebug = false;
error_reporting(E_ERROR | E_PARSE);
// Uncomment the below two lines to enable ldap debug
//$ldapdebug = true;
//error_reporting(E_ALL);

$msg = '';

// If they were inactive session timeout
if (isset($_GET['inactive'])) {
   $msg = 'Your session has timed out from inactivy. Please log in again.';
}

// If they just changed their password.
if (isset($_GET['changed'])) {
   $msg = 'Your password has been changed! Please log in again with your new password.';
}

// If any POST hits this page, attempt to process.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   // Check if local user login.
   if ($_POST['username'] == $config->USER || $_POST['username'] == $config->ADMIN_USER) {
      $auth = new Login();
      if ($auth->checkLoginPost()) {
         // Successful login, refer url redirect
         if (isset($_POST['refer'])) {
            header("location: " . $_POST['refer']);
            exit;
         }
         // Successful login, redirect
         if ($config->LOGINPAGE == 'dashboard') {
            header("location: index.php");
         } else {
            header("location: search.php?submitted=true&p=1&q=&loginsearch=true");
         }
         exit;
      } else {
         // Failed login, inform user.
         $msg = '<i class="glyphicon glyphicon-ban-circle"></i> Incorrect username or password';
      }
   } elseif ($config->LDAP_LOGINS) {
      // check if ldap extension is loaded in php
      if (!extension_loaded('ldap')) {
         die('Error: ldap extension not loaded in PHP');
      }

      // Set debugging
      if ($ldapdebug) {
         ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);
      }

      // connect to ldap/ad server
      $ldap = ldap_connect($config->LDAP_HOST, $config->LDAP_PORT) or die('Could not connect to LDAP/AD server.');

      ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
      ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
      ldap_set_option($ldap, LDAP_OPT_NETWORK_TIMEOUT, 10);

      $username = $_POST['username'];
      $password = $_POST['password'];

      $ldapbasedn = $config->LDAP_BASEDN;
      if ($config->LDAP_USERSDN == "") {
         $ldapusersdn = $ldapbasedn;
      } else {
         $ldapusersdn = $config->LDAP_USERSDN . "," . $ldapbasedn;
      }

      if ($config->LDAP_ALT_BIND) {
         $ldaprdn = 'uid=' . $username . ',' . $ldapusersdn;
         $filter = "(&(cn=*)(memberUid=$username))";
      } elseif ($config->LDAP_ALT_BIND2) {
         $ldaprdn = 'uid=' . $username . ',' . $ldapusersdn;
         $filter = "(&(uid=$username)(objectClass=posixAccount))";
      } else {
         $ldaprdn = $username . '@' . $config->LDAP_DOMAIN;
         $filter = "(sAMAccountName=" . $username . ")";
      }
      $bind = @ldap_bind($ldap, $ldaprdn, $password);

      if ($bind) {
         if ($config->LDAP_GROUPSDN == "") {
            $ldapgroupsdn = $ldapbasedn;
         } else {
            $ldapgroupsdn = $config->LDAP_GROUPSDN . "," . $ldapbasedn;
         }
         // search ldap and get all groups the user is a member of
         if ($config->LDAP_NESTED_GROUPS) {
            // get user dn needed for nested group filter
            $results = ldap_search($ldap, $ldapgroupsdn, $filter);
            $first = ldap_first_entry($ldap, $results);
            $userdn = ldap_get_dn($ldap, $first);
            $filter_nested = "(&(objectClass=group)(member:1.2.840.113556.1.4.1941:=$userdn))";
            $results = ldap_search($ldap, $ldapgroupsdn, $filter_nested, array("cn"));
         } else {
            $results = ldap_search($ldap, $ldapgroupsdn, $filter, array("memberof")); 
         }
         $entries = ldap_get_entries($ldap, $results);
         ldap_close($ldap);

         // add group names dn to groups array
         if ($config->LDAP_ALT_BIND || $config->LDAP_NESTED_GROUPS) {
            $groups = array();
            foreach ($entries as $entry) {
               $groups[] = $entry['dn'];
            }
            $groups = array_filter($groups);
         } else {
            $groups = $entries[0]['memberof'];
         }

         // add group names to groupnames array
         $groupnames = array();
         foreach ($groups as $group) {
            $grpname = explode(",", $group, 2);
            $grpname = explode("=", $grpname[0]);
            $groupnames[] = $grpname[1];
         }
         $groupnames = array_filter($groupnames);

         // check if one of the groups that the user belongs to is in one of the authorized groups
         $authorized = false;
         $ldap_admin = false;
         $ldap_taskpanel_access = false;
         foreach ($groupnames as $group) {
            if (in_array($group, $config->LDAP_ADMIN_GROUPS)) {
               $authorized = true;
               $ldap_admin = true;
               if (in_array($group, $config->LDAP_TASK_PANEL_GROUPS)) {
                  $ldap_taskpanel_access = true;
               }
               break;
            }
            if (in_array($group, $config->LDAP_USER_GROUPS)) {
               $authorized = true;
               if (in_array($group, $config->LDAP_TASK_PANEL_GROUPS)) {
                  $ldap_taskpanel_access = true;
               }
            }
         }

         if ($ldapdebug) {
            echo "-----LDAP DEBUG INFO-----<br>\n";
            echo "LDAP_BASEDN: " . $config->LDAP_BASEDN . "<br>\n";
            echo "LDAP_USERSDN: " . $config->LDAP_USERSDN . "<br>\n";
            echo "LDAP_GROUPSDN: " . $config->LDAP_GROUPSDN . "<br>\n";
            $ldap_alt_bind = ($config->LDAP_ALT_BIND) ? 'TRUE' : 'FALSE';
            echo "LDAP_ALT_BIND: " . $ldap_alt_bind . "<br>\n";
            $ldap_alt_bind2 = ($config->LDAP_ALT_BIND2) ? 'TRUE' : 'FALSE';
            echo "LDAP_ALT_BIND2: " . $ldap_alt_bind2 . "<br>\n";
            $ldap_nested_groups = ($config->LDAP_NESTED_GROUPS) ? 'TRUE' : 'FALSE';
            echo "LDAP_NESTED_GROUPS: " . $ldap_nested_groups . "<br>\n";
            echo "LDAP_ADMIN_GROUPS:<br>\n";
            var_dump($config->LDAP_ADMIN_GROUPS);
            echo "<br>\n";
            echo "LDAP_USER_GROUPS:<br>\n";
            var_dump($config->LDAP_USER_GROUPS);
            echo "<br>\n";
            echo "LDAP_TASK_PANEL_GROUPS:<br>\n";
            var_dump($config->LDAP_TASK_PANEL_GROUPS);
            echo "<br>\n";
            echo "ldapbasedn: " . $ldapbasedn . "<br>\n";
            echo "ldapusersdn: " . $ldapusersdn . "<br>\n";
            echo "ldaprdn: " . $ldaprdn . "<br>\n";
            echo "ldapgroupsdn: " . $ldapgroupsdn . "<br>\n";
            echo "filter: " . $filter . "<br>\n";
            echo ($config->LDAP_NESTED_GROUPS) ? "userdn: " . $userdn . "<br>\n" : "";
            echo ($config->LDAP_NESTED_GROUPS) ? "filternested: " . $filter_nested . "<br>\n" : "";
            echo "results:<br>\n";
            var_dump($results);
            echo "<br>\n";
            echo "entries:<br>\n";
            var_dump($entries);
            echo "<br>\n";
            echo "groupnames:<br>\n";
            var_dump($groupnames);
            echo "<br>\n";
            echo "authorized: ";
            echo ($authorized) ? 'true' : 'false';
            echo "<br>\n";
            echo "ldapadmin: ";
            echo ($ldap_admin) ? 'true' : 'false';
            echo "<br>\n";
            echo "ldaptaskpanel: ";
            echo ($ldap_taskpanel_access) ? 'true' : 'false';
            echo "<br>\n";
            echo "-------------------------------";
            exit;
         }

         // set session vars and login if authorized
         if ($authorized) {
            if (isset($_POST['stayloggedin'])) {
               $_SESSION['stayloggedin'] = true;
            } else {
               $_SESSION['stayloggedin'] = false;
            }
            $_SESSION['loggedin'] = true;
            $_SESSION['last_activity'] = time();
            $_SESSION['username'] = $username;
            $_SESSION['ldapadmin'] = $ldap_admin;
            $_SESSION['ldaptaskpanel'] = $ldap_taskpanel_access;
            $_SESSION['ldapgroups'] = $groupnames;
            $_SESSION['ldaplogin'] = true;

            // Successful login, refer url redirect
            if (isset($_POST['refer'])) {
               header("location: " . $_POST['refer']);
               exit;
            }
            // Successful login, redirect
            if ($config->LOGINPAGE == 'dashboard') {
               header("location: index.php");
            } else {
               header("location: search.php?submitted=true&p=1&q=&loginsearch=true");
            }
            exit;
         } else {
            $msg = '<i class="glyphicon glyphicon-ban-circle"></i> Your username is not in a diskover ldap group';
         }
      } else {
         $msg = '<i class="fas fa-exclamation-circle"></i> Error: ' . ldap_error($ldap) . ' ' . $ldaprdn;
      }
   } else {
      $msg = '<i class="glyphicon glyphicon-ban-circle"></i> Incorrect username or password';
   }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
   <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
      <!-- Global site tag (gtag.js) - Google Analytics -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
      <script>
         window.dataLayer = window.dataLayer || [];

         function gtag() {
            dataLayer.push(arguments);
         }
         gtag('js', new Date());

         gtag('config', 'G-NDFBQ1BYMH');
      </script>
   <?php } ?>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>diskover &mdash; Login</title>
   <link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
   <link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
   <link rel="stylesheet" href="css/diskover.css" media="screen" />
   <link rel="icon" type="image/png" href="images/diskoverfavico.png" />
   <style>
      .login-logo {
         text-align: center;
         padding: 40px 0 0 0;
      }

      .login {
         width: 400px;
         background-color: #272B30;
         box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
         margin: 100px auto;
         border-radius: 10px;
      }

      .login h1 {
         text-align: center;
         color: #ffffff;
         font-size: 24px;
         padding: 0 0 5px 0;
      }

      .login h4 {
         text-align: center;
         color: darkgray;
         font-size: 18px;
      }

      .version {
         text-align: center;
         color: darkgray;
         font-size: 12px;
         padding: 0;
      }

      .login-error {
         text-align: center;
         color: #ffcccc;
         font-size: 16px;
         margin-top: 20px;
         padding: 0 20px;
      }

      .login-error.text-danger:hover {
         color: #ffcccc;
      }

      .login form {
         display: flex;
         flex-wrap: wrap;
         justify-content: center;
         padding-top: 20px;
      }

      .login .input-label {
         display: flex;
         justify-content: center;
         align-items: center;
         width: 50px;
         height: 50px;
         background-color: #1C1E21;
         color: darkgray;
      }

      .login form input[type="password"],
      .login form input[type="text"] {
         width: 310px;
         height: 50px;
         border: 1px solid #000000;
         margin-bottom: 20px;
         padding: 0 15px;
         font-size: 16px;
      }

      .login form input[type="submit"] {
         width: 80%;
         padding: 12px;
         margin-top: 20px;
         margin-bottom: 30px;
         border: 0;
         cursor: pointer;
         font-weight: bold;
         font-size: 16px;
         color: #ffffff !important;
         background-color: #3C4247 !important;
         transition: background-color 0.2s;
         border-radius: 30px;
      }

      .login form input[type="submit"]:hover {
         background-color: #474D54 !important;
         transition: background-color 0.2s;
      }
   </style>
</head>

<body>
   <div class="login">
      <div class="login-logo"><img src="images/diskover.png" alt="diskover" width="249" height="189" /></div>
      <h1>diskover</h1>
      <p class="version"><?php echo "v" . $VERSION; ?></p>
      <p class="login-error text-danger"><?php echo $msg; ?></p>
      <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
         <?php
         if (isset($_GET['refer'])) {
            echo "<input type=\"hidden\" name=\"refer\" value=\"" . $_GET['refer'] . "\">\n";
         }
         ?>
         <label class="input-label" for="username">
            <i class="fas fa-user"></i>
         </label>
         <input type="text" class="form-control" name="username" id="username" placeholder="Username" required autofocus>
         <label class="input-label" for="password">
            <i class="fas fa-lock"></i>
         </label>
         <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
         <div class="checkbox">
            <label><input type="checkbox" name="stayloggedin" id="stayloggedin"> Keep me logged in for 7 days</label>
         </div>
         <input type="submit" id="loginbutton" value="Log In" onclick="loadingShow()">
         <?php if ($config->OAUTH2_LOGINS) {
            echo '<p><i class="fas fa-key"></i> <a href="login.php?ssosignin">Sign in with Single Sign-On (SSO)</a></p>';
         } ?>
      </form>
      <div id="loading">
         <img id="loading-image" width="32" height="32" src="images/ajax-loader.gif" alt="Loading..." />
      </div>
   </div>
</body>

<script type="text/javascript">
   var errormsg = '<?php echo $msg ?>';
   if (errormsg) {
      loadingHide();
   }

   function loadingShow() {
      if (document.getElementById('username').value != '' && document.getElementById('password').value != '') {
         document.getElementById('loading').style.display = 'block';
         document.getElementById('loginbutton').value = 'Loading...';
      }
   }

   function loadingHide() {
      document.getElementById('loading').style.display = 'none';
      document.getElementById('loginbutton').value = 'Login';
   }
</script>

</html>