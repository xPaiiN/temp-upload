<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
example file action Jquery ajax url script
*/

// get post data from Jquery ajax
$cmd = $_POST['cmd'];
$cmd = urldecode($cmd);

// run exec and get output and return value
$output = $retval = null;
exec($cmd, $output, $retval);

$output = implode("\n", $output);

if ($retval > 0) {
    header('HTTP/1.1 500 Internal Server Error');
    echo "Error: $retval <br>";
    echo $output;
} else {
    // print html output
    echo $output;
}