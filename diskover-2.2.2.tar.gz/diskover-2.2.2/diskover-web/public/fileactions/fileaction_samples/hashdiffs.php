<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
Name: hashdiffs.php
Description: Simple HTML viewer of hash diffs in ES index.
*/

$PLUGIN_VERSION = '0.0.2';

// override debug output in fileactions include file
$fileactions_debug = FALSE;

// override html page title in fileactions header include file
$fileactions_pagetitle = 'Hash Diffs File Action';

include 'includes/fileactions.php';

// add css to header inc
$fileactions_header_inc = '
<link rel="stylesheet" href="../css/dataTables.bootstrap.min.css" media="screen" />
<link rel="stylesheet" href="hashdiffs/css/buttons.bootstrap.min.css" media="screen" />
<link rel="stylesheet" href="hashdiffs/css/select.bootstrap.min.css" media="screen" />
<link rel="stylesheet" href="hashdiffs/css/hashdiffs.css" media="screen" />
';

include 'includes/fileactions_header.php';


foreach ($fileinfo as $file) {
	if ($file['type'] != 'directory') {
		echo "Not a directory";
		break;
	}

    $fullpath = $file['fullpath'];
	$index = $file['index'];

	// create cookies used by hashdiffs.js
	createCookie('hashdiffspath', $fullpath);
	createCookie('hashdiffsindex', $index);

    // Main HTML Output
	echo '<nav class="navbar navbar-default navbar-fixed-top">
  	<div class="container-fluid">
    <div class="navbar-header">
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapsible">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<img class="pull-left" title="diskover-web" alt="diskover-web logo" style="position:absolute;left:12px;top:8px;" src="../images/diskovernav.png" width="40" height="30" />
      	<span style="position: absolute; margin-left:50px"><a class="navbar-brand" href="#">Hash Diffs <span style="font-size:12px;">v'.$PLUGIN_VERSION.'</span></a></span>
    </div>
	<ul class="nav navbar-nav navbar-right">
    	<li><a href="#" onclick="window.open(\'\', \'_self\', \'\'); window.close();">Close</a></li>
    </ul>
	</div>
	</nav>';

	echo '<div class="container-fluid cmd-output" style="margin-top:55px">';
    echo '<p style="padding-top:10px; font-weight:bold">'.$fullpath.'</p>';
	echo'<div id="error" class="alert alert-dismissible alert-danger" style="display:none">
		<button type="button" class="close" data-dismiss="alert">&times;</button>
		</div>';

	$timenow = new DateTime("now", new DateTimeZone($GLOBALS['config']->TIMEZONE));

	echo '<p class="text-right">Updated ' . $timenow->format('m/d/Y, h:i:s A T') . ' <a href="#" onclick="location.reload(true)">update</a></p>';

    echo '<table id="hashdiffs-filelist" class="table table-striped table-hover table-condensed" style="width:100%">';
    echo '<thead>
		<tr>
			<th>Name</th>
			<th>Path</th>
			<th>Size</th>
			<th>Last Modified</th>
			<th>Diff</th>
			<th>Diff Index</th>
			<th>xxhash</th>
			<th>md5</th>
			<th>sha1</th>
			<th>sha256</th>
	 ';
    echo '</tr>
		</thead>
		</table>
		<div class="text-right">
			<button onclick="$(\'html, body\').animate({ scrollTop: 0 }, \'fast\');" type="button" class="btn btn-default" title="go to top"><i class="glyphicon glyphicon-triangle-top"></i> To top</button>
		</div>
		</div>';

    // Break out of loop, remove this to display all selected folders
    break;
}

// add js files to footer
$fileactions_footer_inc = '
<script language="javascript" src="../js/jquery.min.js"></script>
<script language="javascript" src="../js/bootstrap.min.js"></script>
<script language="javascript" src="../js/jquery.dataTables.min.js"></script>
<script language="javascript" src="../js/dataTables.bootstrap.min.js"></script>
<script language="javascript" src="hashdiffs/js/dataTables.buttons.min.js"></script>
<script language="javascript" src="hashdiffs/js/buttons.bootstrap.min.js"></script>
<script language="javascript" src="hashdiffs/js/buttons.html5.min.js"></script>
<script language="javascript" src="hashdiffs/js/buttons.colVis.min.js"></script>
<script language="javascript" src="hashdiffs/js/dataTables.select.min.js"></script>
<script language="javascript" src="hashdiffs/js/select.bootstrap.min.js"></script>
<script language="javascript" src="../js/file-size.js"></script>
<script language="javascript" src="hashdiffs/js/hashdiffs.js"></script>
';

include 'includes/fileactions_footer.php';
