#!/usr/bin/env python3
"""
diskover
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/


Print json directory list using scandir and path from arg

"""

import sys, os, json
from datetime import datetime

# path to get directory list
path = sys.argv[1]

items = {}
for entry in os.scandir(path):
    if entry.is_symlink():
        pass
    else:
        if entry.is_dir():
            pathsep = '/'
        else:
            pathsep = ''
        size = entry.stat().st_size
        mtime = datetime.utcfromtimestamp(int(entry.stat().st_mtime)).isoformat()
        items[entry.name + pathsep] = [mtime, size]

# print out items
print(json.dumps(items))