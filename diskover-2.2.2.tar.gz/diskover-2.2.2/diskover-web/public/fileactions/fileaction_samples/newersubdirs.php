<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
example file action to look for subdirs with newer ctime and mtime than the directory selected
for Linux or MacOS
*/


// override debug output in fileactions include file
//$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// in this example we are listing all selected directory items on search results page
// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array


foreach ($fileinfo as $file) {
    // skip any files selected
    if ($file['type'] != 'directory') {
        echo "Not a directory";
        continue;
    }

    $fullpath = $file['fullpath'];
    // uncomment below and set to translate paths
    //$path_translations = array(
    //    '/^\//' => '/mnt/'
    //);
    //$fullpath = translate_path($fullpath, $path_translations);

    // run command to find all directories that have a newer ctime and mtime than fullpath's ctime and mtime
    $cmd = 'date && 
            ls -lad "'.$fullpath.'" && 
            find "'.$fullpath.'" -type d -cnewer "'.$fullpath.'" -newer "'.$fullpath.'" -exec ls -lad {} \; | awk \'{n++;print}END{if(n>0){print "\n",n,"newer subdirs"}else{print "no newer subdirs"}}\'
            ';

    // run exec and get output and return value
    $output = $retval = null;
    exec($cmd, $output, $retval);

    // print html output
    echo '
    <div class="container-fluid cmd-output">
    Command: ' . $cmd . '<br>
    Status:<br>
    <pre>' . $retval .'</pre>
    Output:<br>
    <pre>' . implode("\n", $output) . '</pre>
    </div>
    ';
}


include 'includes/fileactions_footer.php';