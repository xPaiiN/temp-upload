<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
Name: remotescandir.php
remotescandir.php file for Live View File Action

Uses PHP cURL to connect to scandir.php on remote web server.
*/

// set php time limit for page to timeout
set_time_limit(60);

// remote web server host url hosting scandir.php
$remote_server_url = "https://<web server host>";

// get path from liveview.js datatable ajax data path param
if (isset($_GET['path'])) {
    $lvpath = html_entity_decode($_GET['path']);
} else {
    $lvpath = "";
}

$passthru_url = $remote_server_url . '/scandir.php?path=' . $lvpath;

// Instantiate a cURL resource instance
$ch = curl_init();

// Set the URL to be used
curl_setopt($ch, CURLOPT_URL, $passthru_url);

// Strip HTTP header information from response
curl_setopt($ch, CURLOPT_HEADER, false); //The false values causes HTTP headers to be stripped out

// Set curl timeouts
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);

// Retrieve the URL and pass along
curl_exec($ch);

// Close the cURL resource and free system resources
curl_close($ch);