<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
File action example using ajax for a long running Python script that takes a while to get results
*/

// override debug output in fileactions include file
$fileactions_debug = FALSE;

include 'includes/fileactions.php';
include 'includes/fileactions_header.php';


// you can set fileactions_debug to TRUE above for debug info to print out fileinfo array

foreach ($fileinfo as $file) {
    $fullpath = $file['fullpath'];
    // uncomment below and set to translate paths
    //$path_translations = array(
    //    '/^\//' => '/mnt/'
    //);
    //$fullpath = translate_path($fullpath, $path_translations);

    $index = $file['index'];
    $type = $file['type'];

    // run a python script
    // this cmd will be sent by POST to ajaxexec.php to run
    // and send back response when done
    $cmd = 'python3 somescript.py "' . $fullpath . '" ' . $type . ' ' . $index . ' 2>&1';
    //$cmd = 'python3 somescript.py "' . $fullpath . '" ' . $type . ' ' . $index;
    $cmd_enc = urlencode($cmd);

    // print html output
    echo '
    <div class="container-fluid cmd-output">
    Command: ' . $cmd . '<br>
    Result: <span id="result"></span><br>
    Output:<br>
    <pre id="response"></pre>
    <div class="progress" id="progress">
        <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
    </div>

    <script language="javascript" src="../js/jquery.min.js"></script>
    <script type="text/javascript">
    jQuery(document).ready(function($){
        var resp = $("#response");
        var res = $("#result");
        var prog = $("#progress");
        $.ajax({
            type: "POST",
            url: "ajaxexec.php",
            data: {cmd: "'.$cmd_enc.'"},

            beforeSend: function(xhr){
                resp.html("Searching for file sequence, please wait...");
            },

            error: function(qXHR, textStatus, errorThrow){
                var err = qXHR.responseText;
                resp.html("There was an error: " + err);
                res.html(textStatus);
                prog.hide();
            },

            success: function(data, textStatus, jqXHR){
                resp.html(data);
                res.html(textStatus);
                prog.hide();
            }
        });
    });
    </script>
    </div>
    ';
}


include 'includes/fileactions_footer.php';