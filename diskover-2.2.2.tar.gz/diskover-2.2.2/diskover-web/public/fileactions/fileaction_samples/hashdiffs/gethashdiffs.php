<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
Name: gethashdiffs.php
gethashdiffs.php file for Hash Diffs File Action
*/

require '../../../vendor/autoload.php';
use Elasticsearch\Common\Exceptions\Missing404Exception;
require "../../../src/diskover/Auth.php";
require "../../../src/diskover/Diskover.php";



// set php time limit for page to timeout
set_time_limit(60);

// get path from hashdiffs.js datatable ajax data path param
if (isset($_GET['path'])) {
    $hashdiffs_path = $_GET['path'];
} else {
    $hashdiffs_path = "";
}

// get index from hashdiffs.js datatable ajax data index param
if (isset($_GET['index'])) {
    $hashdiffs_index = $_GET['index'];
} else {
    $hashdiffs_index = "";
}

$fileinfo = array();

if (!empty($hashdiffs_path) && !empty($hashdiffs_index)) {
    // Search Elasticsearch index
    // Setup search query for files in path with tags:diff*
    try {
        $results = [];
        $searchParams = [];

        // Scroll parameter alive time
        $searchParams['scroll'] = "30s";

        // scroll size
        $searchParams['size'] = 1000;

        // es index to search
        $searchParams['index'] = $hashdiffs_index;

        $searchParams['body'] = [
            '_source' => ['name', 'size', 'parent_path', 'mtime', 'tags', 'hash'],
            'query' => [
                'query_string' => [
                    'query' => 'parent_path:' . escape_chars($hashdiffs_path). '* AND tags:diff* AND type:file',
                    'analyze_wildcard' => 'true'
                ]
            ]
        ];

        // check if we need to apply any filters to search
        $searchParams = filterIndexMappingPaths($searchParams);
        $searchParams = filterLDAPGroups($searchParams);
        $searchParams = filterSearchResults($searchParams);

        // Send search query to Elasticsearch
        $queryResponse = $client->search($searchParams);

        // set total hits
        $total = $queryResponse['hits']['total']['value'];

        $i = 1;
        // Loop through all the pages of results
        while ($i <= ceil($total / $searchParams['size'])) {
            // add files in directory to results array
            foreach ($queryResponse['hits']['hits'] as $hit) {
                $diff = array();
                $diff_index = array();
                $diff_hash_xxhash = $diff_hash_md5 = $diff_hash_sha1 = $diff_hash_sha256 = 'null';
                // determine what is different based on doc tags
                foreach ($hit['_source']['tags'] as $tag) {
                    // skip any tags that don't start with diff
                    if (strpos($tag, 'diff') !== 0) {
                        continue;
                    }
                    $diff_arr = explode('_', $tag);
                    if ($diff_arr[1] === 'newfile') {
                        $diff[] = "new file";
                        $diff_index[] = $diff_arr[2];
                    } else if ($diff_arr[1] === 'hash') {
                        $diff[] = "hash (" . $diff_arr[2] . ")";
                        $diff_index[] = $diff_arr[3];
                        if ($diff_arr[2] == 'xxhash') {
                            $diff_hash_xxhash = $diff_arr[4];
                        } else if ($diff_arr[2] == 'md5') {
                            $diff_hash_md5 = $diff_arr[4];
                        } else if ($diff_arr[2] == 'sha1') {
                            $diff_hash_sha1 = $diff_arr[4];
                        } else if ($diff_arr[2] == 'sha256') {
                            $diff_hash_sha256 = $diff_arr[4];
                        }
                    }
                }
                // add doc source data to fileinfo array
                $fileinfo[] = [
                    'name' => $hit['_source']['name'],
                    'path' => $hit['_source']['parent_path'] . "/" . $hit['_source']['name'],
                    'size' => formatBytes($hit['_source']['size']),
                    'mtime' => utcTimeToLocal($hit['_source']['mtime']),
                    'diff' => $diff,
                    'diff_index' => join(", ", $diff_index),
                    'xxhash' => (!empty($hit['_source']['hash']['xxhash'])) ? $hit['_source']['hash']['xxhash'] . " (" . $diff_hash_xxhash . ")" : "-",
                    'md5' => (!empty($hit['_source']['hash']['md5'])) ? $hit['_source']['hash']['md5'] . " (" . $diff_hash_md5 . ")" : "-",
                    'sha1' => (!empty($hit['_source']['hash']['sha1'])) ? $hit['_source']['hash']['sha1'] . " (" . $diff_hash_sha1 . ")" : "-",
                    'sha256' => (!empty($hit['_source']['hash']['sha256'])) ? $hit['_source']['hash']['sha256'] . " (" . $diff_hash_sha256 . ")" : "-",
                ];
            }

            $scroll_id = $queryResponse['_scroll_id'];

            $queryResponse = $client->scroll([
                "body" => [
                    "scroll_id" => $scroll_id,
                    "scroll" => "30s"
                ]
            ]);

            $i += 1;
        }
    } catch (Exception $e) {
        echo json_encode(array('error' => $e->getMessage()));
        exit;
    }
}

echo json_encode(array('data' => $fileinfo));
