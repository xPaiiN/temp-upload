/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/*
Name: hashdiffs.js
hashdiffs.js file for Hash Diffs File Action
*/

// location of ajax url to gethashdiffs.php
var gethashdiffs_url = 'hashdiffs/gethashdiffs.php';


$(document).ready(function () {
    // hash diffs data table
    var hashdiffs_path = getCookie('hashdiffspath');
    var hashdiffs_index = getCookie('hashdiffsindex');

    var table = $("#hashdiffs-filelist").DataTable({
        'ajax': {
            'url': gethashdiffs_url,
            'data': {
                'path': hashdiffs_path,
                'index': hashdiffs_index
            }
        },
        "deferRender": true,
        'columns': [
            { data: 'name' },
            { data: 'path' },
            { data: 'size' },
            { data: 'mtime' },
            { data: 'diff' },
            { data: 'diff_index' },
            { data: 'xxhash'},
            { data: 'md5' },
            { data: 'sha1' },
            { data: 'sha256' }
        ],
        'stateSave': true,
        'lengthMenu': [10, 25, 50, 100, 200, 300, 500, 1000],
        'pageLength': 50,
        'columnDefs': [{
                'type': 'file-size',
                'targets': 2
            },
            {
                'targets': 0,
                render: function (data, type, row, meta) {
                    var html = '<span class="wrap"><i class="far fa-file" style="color:#8B949E; padding-right:6px; font-size:16px;"></i> ' + data + '</span>';
                    return html;
                }
            },
            {
                'targets': [1,6,7,8,9],
                render: function (data, type, row, meta) {
                    if (data === null) {
                        data = '-';
                    }
                    var html = '<span class="wrap"> ' + data + '</span>';
                    return html;
                }
            },
            {
                'targets': 4,
                render: function (data, type, row, meta) {
                    var html = '';
                    data.forEach((item) => {
                        if (item.includes('new file')) {
                            html += '<span style="color:yellow;display:inline-block;"><i title="' + item + '" class="fas fa-exclamation-circle></i>&nbsp;new</span> ';
                        } else if (item.includes('hash')) {
                            html += '<span style="color:red;display:inline-block;"><i title="' + item + '" class="fas fa-exclamation-circle"></i>&nbsp;' + item + '</span> ';
                        }
                    });
                    return html;
                }
            }
        ],
        'language': {
            'emptyTable': 'No files found'
        },
        buttons: [
            {
                extend: 'copy',
                title: '',
                header: false,
                exportOptions: {
                    columns: 1
                }
            },
            'colvis', 'selectNone', 'selectAll'
        ],
        'select': true,
        initComplete : function () {
            table.buttons().container()
                .appendTo( '#hashdiffs-filelist_wrapper .col-sm-6:eq(0)' );
            
            $('input[type=search]').val(''); // Clear Search input.
            table.search('').draw(); // Rebind all data.
        }
    });
    
    $.fn.dataTable.ext.errMode = function ( settings, helpPage, message ) { 
        console.log(message);
        $("#error").show();
        $("#error").append(message); 
    };
});

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
