<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

// file actions footer include file

if (!isset($fileactionresult)) {
	$fileactionresult = 1;
}
logFileAction();

?>
	<script language="javascript" src="../js/jquery.min.js"></script>
	<script language="javascript" src="../js/bootstrap.min.js"></script>
	<script language="javascript" src="../js/diskover.js"></script>
	<?php echo (isset($fileactions_footer_inc)) ? $fileactions_footer_inc : '' ?>
</body>
</html>