<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "../src/diskover/Diskover.php";


$q = rawurlencode($_GET['q']);
$p = $_GET['p'];
$resultsize = $_GET['resultsize'];
$export = $_GET['export'];
$export_type = $_GET['export_type'];

$downloadurl = "export_download.php?q=$q&p=$p&resultsize=$resultsize&export=$export&export_type=$export_type";

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>diskover &mdash; Export Download</title>
	<link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
	<link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
	<link rel="stylesheet" href="css/diskover.css" media="screen" />
	<link rel="icon" type="image/png" href="images/diskoverfavico.png" />
    <style>
    code {
        background-color:#333!important;
        color: #56B6C2!important;
    }
    strong {
        color: gray;
    }
    </style>
</head>
<body>
<p>Downloading export file... please do not refresh the browser or close this window until the download completes.</p>
<p><a href="#" onclick="window.close('','_parent','');">Close window</a></p>
<!-- start the download in a hidden iframe -->
<iframe name="downloadiframe" width="0" height="0" style="display:none" src="<?php echo $downloadurl ?>"></iframe>
</body>
</html>