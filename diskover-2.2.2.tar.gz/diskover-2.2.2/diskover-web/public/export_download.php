<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "../src/diskover/Diskover.php";

session_write_close();
ini_set('memory_limit', '256M');
set_time_limit(600);

// es search size
$searchsize = 1000;
// es scroll time
$scrolltime = '1m';


// search query
$q = $_GET['q'];
// curent page
$p = $_GET['p'];
// result size of search results
$resultsize = $_GET['resultsize'];
// type of export
$export = $_GET['export'];
// doctype of export
$export_type = $_GET['export_type'];


// date of export
$dt = new DateTime('now', new DateTimeZone('UTC'));
$dt->setTimezone(new DateTimeZone($config->TIMEZONE));
$export_date = $dt->format('ymd_his');

// start the output buffer
ob_start();

// set PHP headers for CSV/JSON output
if ($export == 'csv') {
header('Content-Type: text/csv; charset=utf-8');
} elseif ($export == 'json') {
    header('Content-type: application/json; charset=utf-8');
} else {
    exit;
}
// disposition / encoding on response body
header("Content-Disposition: attachment; filename=diskover_export_{$export_type}_{$export_date}.{$export}");

// Get search results from Elasticsearch
$results = [];
$searchParams = [];

// Setup search query
$searchParams['index'] = $mnclient->getSearchIndex($esIndex);

// Scroll parameter alive time
$searchParams['scroll'] = $scrolltime;


// search size (number of results to return per page)
if ((string)$p === "all") {
    // scroll size
    $searchParams['size'] = $searchsize;
} else {
    if (!empty($resultsize)) {
        $searchParams['size'] = $resultsize;
    } elseif (getCookie("resultsize") != "") {
        $searchParams['size'] = getCookie("resultsize");
    } else {
        $searchParams['size'] = $config->SEARCH_RESULTS;
    }
}

// match all if search field empty
if (empty($q)) {
    $searchParams['body'] = [
        'query' => [
            'query_string' => [
                'query' => 'type:(file OR directory)'
            ]
        ]
    ];
    // match what's in the search field
} else {
    // get request string from predict_search
    $request = predict_search($q);
    $searchParams['body'] = [
        'query' => [
            'query_string' => [
                'query' => '(' . $request . ') AND type:' . $export_type,
                'analyze_wildcard' => 'true',
                'fields' => ['name^5', 'name.text', 'parent_path', 'parent_path.text', 'extension'],
                'default_operator' => 'AND'
            ]
        ]
    ];
}

// check if we need to apply any filters to search
$searchParams = filterIndexMappingPaths($searchParams);
$searchParams = filterLDAPGroups($searchParams);
$searchParams = filterSearchResults($searchParams);

// Sort search results
$searchParams = sortSearchResults($_GET, $searchParams);

if ($export == 'csv') {
    // clean output buffer
    ob_end_clean();

    // open file output for csv
    $df = fopen("php://output", 'w');

    try {
        // Send search query to Elasticsearch and get scroll id and first page of results
        $queryResponse_fields = $client->search($searchParams);
    } catch (Exception $e) {
        handleError('ES Error: ' . $e->getMessage(), false);
    }
    // array to hold csv header row
    $fields = array();
}

try {
    // Send search query to Elasticsearch and get scroll id and first page of results
    $queryResponse = $client->search($searchParams);
} catch (Exception $e) {
    handleError('ES Error: ' . $e->getMessage(), false);
}

// set total hits
$total = $queryResponse['hits']['total']['value'];


if ((string)$p === "all") {
    if ($export == 'csv') {
        // Loop through all the pages of results and get all field names and column titles
        while (count($queryResponse_fields['hits']['hits']) > 0) {
            
            // Get fields
            foreach ($queryResponse_fields['hits']['hits'] as $hit) {
                foreach ($hit['_source'] as $key => $val) {
                    if (!array_key_exists($key, $fields)) {
                        $fields[$key] = array();
                    }
                    if (is_array($val)) {
                        foreach ($val as $v_key => $v_val) {
                            $v = $key . '.' . $v_key;
                            if (!in_array($v, $fields[$key])) {
                                $fields[$key][] = $v;
                            }
                        }
                    }
                }
            }

            $scroll_id = $queryResponse_fields['_scroll_id'];

            $queryResponse_fields = $client->scroll([
                "body" => [
                    "scroll_id" => $scroll_id,
                    "scroll" => $scrolltime
                ]
            ]);
        }

        // clear current scroll window
        if (!empty($scroll_id)) {
            $client->clearScroll(array('scroll_id' => $scroll_id));
            $scroll_id = null;
        }

        // write csv column titles
        $line = array();
        foreach ($fields as $key => $value) {
            if (count($value) > 0) {
                foreach ($value as $v) {
                    $line[] = $v;
                }
            } else {
                $line[] = $key;
            }
        }
        fputcsv($df, $line);
    }

    // Loop through all the pages of results
    while (count($queryResponse['hits']['hits']) > 0) {

        // Get results and export to csv when size of results array reaches searchsize
        foreach ($queryResponse['hits']['hits'] as $hit) {
            $results[] = $hit['_source'];
            if (sizeof($results) >= $searchsize) {
                export($results);
                unset($results);
            }
        }

        $scroll_id = $queryResponse['_scroll_id'];

        $queryResponse = $client->scroll([
            "body" => [
                "scroll_id" => $scroll_id,
                "scroll" => $scrolltime
            ]
        ]);
    }

    // clear current scroll window
    if (!empty($scroll_id)) {
        $client->clearScroll(array('scroll_id' => $scroll_id));
        $scroll_id = null;
    }

} else {
    if ($export == 'csv') {
        $i = 1;
        // Loop through all the pages of results and get field names and column titles
        while ($i <= ceil($total/$searchParams['size'])) {

            // check if we have the results for the page we are on
            if ($i == $p) {
                // Get fields
                foreach ($queryResponse_fields['hits']['hits'] as $hit) {
                    foreach ($hit['_source'] as $key => $val) {
                        if (!array_key_exists($key, $fields)) {
                            $fields[$key] = array();
                        }
                        if (is_array($val)) {
                            foreach ($val as $v_key => $v_val) {
                                $v = $key . '.' . $v_key;
                                if (!in_array($v, $fields[$key])) {
                                    $fields[$key][] = $v;
                                }
                            }
                        }
                    }
                }
                // end loop
                break;
            }

            $scroll_id = $queryResponse_fields['_scroll_id'];

            $queryResponse_fields = $client->scroll([
                "body" => [
                    "scroll_id" => $scroll_id,
                    "scroll" => $scrolltime
                ]
            ]);

            $i += 1;
        }

        // clear current scroll window
        if (!empty($scroll_id)) {
            $client->clearScroll(array('scroll_id' => $scroll_id));
            $scroll_id = null;
        }

        // write csv column titles
        $line = array();
        foreach ($fields as $key => $value) {
            if (count($value) > 0) {
                foreach ($value as $v) {
                    $line[] = $v;
                }
            } else {
                $line[] = $key;
            }
        }
        fputcsv($df, $line);
    }

    $i = 1;
    // Loop through all the pages of results
    while ($i <= ceil($total/$searchParams['size'])) {

    // check if we have the results for the page we are on
        if ($i == $p) {
            // Get results
            foreach ($queryResponse['hits']['hits'] as $hit) {
                $results[] = $hit['_source'];
                if (sizeof($results) >= $searchsize) {
                    export($results);
                    unset($results);
                }
            }
            // end loop
            break;
        }

        $scroll_id = $queryResponse['_scroll_id'];

        $queryResponse = $client->scroll([
            "body" => [
                "scroll_id" => $scroll_id,
                "scroll" => $scrolltime
            ]
        ]);

        $i += 1;
    }

    // clear current scroll window
    if (!empty($scroll_id)) {
        $client->clearScroll(array('scroll_id' => $scroll_id));
        $scroll_id = null;
    }
}


// export any remaining docs
export($results);
unset($results);

// close csv file output and flush buffers
if (isset($df)) {
    fclose($df);
    ob_flush();
}


function array2csv($arr) {
    global $df, $fields;

    if (count($arr) == 0) {
     return null;
    }

    // write rows
    foreach ($arr as $value) {
        $line = array();

        foreach ($fields as $fieldname => $fieldsubnames) {
            // add empty column(s) and continue if doc source does not contain matching field
            if (!array_key_exists($fieldname, $value)) {
                if (count($fieldsubnames) === 0) {
                    $line[] = '';
                } else {
                    $i = 0;
                    while ($i < count($fieldsubnames)) {
                        $line[] = '';
                        $i++;
                    }
                }
                continue;
            }
            $val = $value[$fieldname];
            if (is_array($val)) {
                foreach ($val as $v_val) {
                    if (is_bool($v_val)) {
                        $v_val = ($v_val) ? 'true' : 'false';
                    }
                    $line[] = (isset($v_val)) ? $v_val : '';
                }
                // add empty column(s) if size of doc field array does not equal column titles
                if (count($val) !== count($fieldsubnames)) {
                    $i = count($val);
                    while ($i < count($fieldsubnames)) {
                        $line[] = '';
                        $i++;
                    }
                }
            } else {
                if (is_bool($val)) {
                    $val = ($val) ? 'true' : 'false';
                }
                $line[] = (isset($val)) ? $val : '';
            }
        }
        fputcsv($df, $line);
    }
}

function export($results_source) {
    global $export;

    if (count($results_source) == 0) {
        return null;
    }
    if ($export == "json") {
        echo json_encode($results_source);
    } elseif ($export == "csv") {
        echo array2csv($results_source);
    }
}
