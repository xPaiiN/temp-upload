<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/

All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/

Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

/* diskover REST API
 */

require '../vendor/autoload.php';
require '../src/diskover/config_inc.php';

use Elasticsearch\Common\Exceptions\Missing404Exception;
use diskover\ApiLogin;
use diskover\ApiLdapLogin;

class ValidationError extends Exception { }

error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE & ~E_DEPRECATED);

// api version
$API_VER = "2.0.18";


// authenticate user
if ($config->API_AUTH_ENABLED) {
    // HTTP basic auth
    if (!isset($_SERVER['PHP_AUTH_USER'])) {
        header('WWW-Authenticate: Basic realm="diskover REST API"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Access denied. You did not enter a username and password.';
        exit;
    }
    // verify api username and password
    $ldaplogin = false;
    $auth = new ApiLogin();
    if (!$auth->checkApiLogin()) {
        if ($config->API_AUTH_LDAP_ENABLED) {
            // LDAP/AD auth
            // verify ldap/ad username and password and api group membership
            $auth = new ApiLdapLogin();
            $auth->checkApiLdapLogin();
            $ldapadmin = $auth->ldapadmin;
            $ldapgroups = $auth->ldapgroups;
            $username = $auth->user;
            $ldaplogin = true;
        } else {
            header('WWW-Authenticate: Basic realm="diskover REST API"');
            header('HTTP/1.0 401 Unauthorized');
            echo 'Access denied! Incorrect username or password.';
            exit;
        }
    }
}

require "../src/diskover/Diskover.php";

// set session vars
if ($config->API_AUTH_ENABLED) {
    if ($ldaplogin) {
        $_SESSION['ldaplogin'] = true;
        if ($ldapadmin) {
            $_SESSION['ldapadmin'] = true;
        } else {
            $_SESSION['ldapadmin'] = false;
        }
        $_SESSION['ldapgroups'] = $ldapgroups;
    } else {
        $_SESSION['ldaplogin'] = false;
    }
    $_SESSION['username'] = $username;
}

// get the HTTP method, path and body of the request
$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['PATH_INFO'], '/'));
$input = json_decode(file_get_contents('php://input'), true);

// get the URL query of the request
$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$query = parse_url($url, PHP_URL_QUERY);

// split path request into endpoint array
$endpoint = [];
foreach ($request as $r) {
    $endpoint[] = $r;
}

// call endpoint based on HTTP method
switch ($method) {
    case 'GET':
        get($endpoint, $query);
        break;
    case 'PUT':
        put($endpoint, $input);
        break;
    case 'POST':
        post($endpoint, $input);
        break;
    case 'DELETE':
        delete($endpoint, $input);
        break;
}

function json_response($code = 200, $message = null, $pretty = false)
{
    // clear the old headers
    header_remove();
    // set the actual code
    http_response_code($code);
    // set the header to make sure cache is forced
    header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
    // treat this as json
    header('Content-Type: application/json');
    $status = array(
        200 => '200 OK',
        400 => '400 Bad Request',
        422 => '422 Unprocessable Entity',
        500 => '500 Internal Server Error'
    );
    // ok, validation error, or failure
    header('Status: ' . $status[$code]);
    // pretty print ?
    $pretty_print = ($pretty) ? JSON_PRETTY_PRINT : null;
    // return the encoded json
    return json_encode(array(
        'status' => $code < 300, // success or not?
        'message' => $message
    ), $pretty_print);
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function read_file_contents($filename)
{
    if (!is_readable($filename)) {
        throw new Exception('api error ' . $filename . ' does not exist or is not readable');
    }
    $data = file_get_contents($filename);
    if (is_bool($data) && $data === FALSE) {
        throw new Exception('api error reading ' . $filename);
    }
    if (is_string($data) && $data === '') {
        throw new Exception('api error ' . $filename . ' is empty');
    }
    return $data;
}

function write_file_contents($filename, $jsondata)
{
    if (!is_writable($filename)) {
        throw new Exception('api error ' . $filename . ' does not exist or is not writable');
    }
    $res = file_put_contents($filename, $jsondata, LOCK_EX);
    if (is_bool($res) && $res === FALSE) {
        throw new Exception('api error writing ' . $filename);
    }
    if (is_int($res) && $res === 0) {
        throw new Exception('api error no data written ' . $filename);
    }
}

function lock_file($file, $filename)
{
    $lock = flock($file, LOCK_SH);
    if (!$lock) {
        throw new Exception('api error could not lock file ' . $filename);
    }
}

function unlock_file($file)
{
    flock($file, LOCK_UN);
    fclose($file);
}

function post($endpoint, $input)
{
    global $client, $mnclient, $ldaplogin, $ldapadmin;

    // deny access for non-admin ldap user
    if ($ldaplogin && !$ldapadmin) {
        header('WWW-Authenticate: Basic realm="diskover REST API"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Access Denied! diskover LDAP admin group membership required for POST.';
        exit;
    }

    switch ($endpoint) {
        case $endpoint[0] == 'addtask':
            $validation_errors = array();

            try {
                if (empty($input["type"])) {
                    array_push($validation_errors, '"type" is required');
                    throw new ValidationError(json_encode($validation_errors));
                }
                $task_type = $input["type"];
                $run_now = isset($input["run_now"]) ? $input["run_now"] : false;
                if (empty($input["name"])) {
                    array_push($validation_errors, '"name" is required');
                } else {
                    $name = test_input($input["name"]);
                }
                $desc = test_input($input["description"]);
                $schedulemin = $input["run_min"];
                if (empty($input["custom_schedule"]) && empty($schedulemin) && !is_numeric($schedulemin)) {
                    array_push($validation_errors, '"run_min" is required');
                } else if ($schedulemin !== '*' && ($schedulemin < 0 || $schedulemin > 59) ){
                    array_push($validation_errors, '"run_min" must be between 0 and 59');
                }
                $schedulehour = $input["run_hour"];
                if (empty($input["custom_schedule"]) && empty($schedulehour) && !is_numeric($schedulehour)) {
                    array_push($validation_errors, '"run_hour" is required');
                } else if ( $schedulehour !== '*' && ($schedulehour < 0 || $schedulehour > 23) ) {
                    array_push($validation_errors, '"run_hour" must be between 0 and 23');
                }
                $scheduledayofmonth = $input["run_day_month"];
                if (empty($input["custom_schedule"]) && empty($scheduledayofmonth) && !is_numeric($scheduledayofmonth)) {
                    array_push($validation_errors, '"run_day_month" is required');
                } else if ($scheduledayofmonth !== '*' && ($scheduledayofmonth < 1 || $scheduledayofmonth > 31) ) {
                    array_push($validation_errors, '"run_day_month" must be between 1 and 31');
                }
                $schedulemonth = $input["run_month"];
                if (empty($input["custom_schedule"]) && empty($schedulemonth) && !is_numeric($schedulemonth)){
                    array_push($validation_errors, '"run_month" is required');
                } else if ( $schedulemonth !== '*' && ($schedulemonth < 1 || $schedulemonth > 12) ) {
                    array_push($validation_errors, '"run_month" must be between 1 and 12');
                }
                $scheduledayofweek = $input["run_day_week"];
                if (empty($input["custom_schedule"]) && empty($scheduledayofweek) && !is_numeric($scheduledayofweek)) {
                    array_push($validation_errors, '"run_day_week" is required');
                } else if ( $scheduledayofweek !== '*' && ($scheduledayofweek < 0 || $scheduledayofweek > 6) ) {
                    array_push($validation_errors, '"run_day_week" must be between 0 and 6');
                }
                $customschedule = test_input($input["custom_schedule"]);
                if (!empty($input["custom_schedule"]) &&
                    !preg_match('/^([1-5]?[0-9]|\*\/[1-5]?[0-9]|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*) ((2[0-3]|1[0-9]|[0-9])|\*\/(2[0-3]|1[0-9]|[0-9])|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*) ((3[01]|[12][0-9]|[1-9])|\*\/(3[01]|[12][0-9]|[1-9])|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*) ((1[0-2]|[1-9])|\*\/(1[0-2]|[1-9])|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*) ([0-6]|\*\/[0-6]|([1-5]?[0-9]((\,|\-)[1-5]?[0-9])*)+|\*)$/', $customschedule)
                ) {
                    array_push($validation_errors, '"custom_schedule" is invalid');
                } elseif (!empty($input["custom_schedule"])) {
                    // update scheduled time with custom schedule
                    $customschedule_arr = explode(" ", $customschedule);
                    $schedulemin = $customschedule_arr[0];
                    $schedulehour = $customschedule_arr[1];
                    $scheduledayofmonth = $customschedule_arr[2];
                    $schedulemonth = $customschedule_arr[3];
                    $scheduledayofweek = $customschedule_arr[4];
                }
                $envvars = $input["env_vars"];
                $precommand = $input["pre_command"];
                $precommandargs = $input["pre_command_args"];
                $postcommand = $input["post_command"];
                $postcommandargs = $input["post_command_args"];
                if (preg_match('/\{indexname\}/', $postcommandargs) && empty($input["custom_index_name"])) {
                    array_push($validation_errors, '"custom_index_name" is required when using {indexname}');
                }

                if (!is_numeric($input["retries"])) {
                    array_push($validation_errors, '"retries" number required');
                } else {
                    $retries = test_input($input["retries"]);
                }
                if (!is_numeric($input["retry_delay"])) {
                    array_push($validation_errors, '"retry_delay" number is required');
                } else {
                    $retrydelay = test_input($input["retry_delay"]);
                }
                if (!is_numeric($input["timeout"])) {
                    array_push($validation_errors, '"timeout" number required');
                } else {
                    $timeout = test_input($input["timeout"]);
                }
                $assignedworker = $input["assigned_worker"];
                $email = test_input($input["email"]);
                if (!empty($input["email"])) {
                    // check if e-mail address' are well-formed
                    $email_list = explode(',', str_replace(' ', '', $email));
                    foreach ($email_list as $emailaddr) {
                        if (!filter_var($emailaddr, FILTER_VALIDATE_EMAIL)) {
                            array_push($validation_errors, '"email" Invalid email format');
                            break;
                        }
                    }
                }
                $maketemplate = isset($input["make_template"]) ? $input["make_template"] : false;
                $templatename = test_input($input["template_name"]);
                if (!empty($input["make_template"]) && empty($templatename)) {
                    array_push($validation_errors, '"template_name" is required');
                }
                $disabled = isset($input["disabled"]) ? $input["disabled"] : false;

                //
                // its an INDEX task
                //
                if (strtolower($task_type) == 'index' ) {
                    if (empty($input["crawl_paths"])) {
                        array_push($validation_errors, '"crawl_paths" is required');
                    } elseif (preg_match('/\,/', $input["crawl_paths"]) || preg_match('/\w\s\w/', $input["crawl_paths"])) {
                        array_push($validation_errors, '"crawl_paths" invalid');
                    } else {
                        $paths = $input["crawl_paths"];
                    }
                    $altscanner = $input["alt_scanner"];
                    $clioptions = $input["cli_options"];
    
                    $autoindexname = isset($input["auto_index_name"]) ? $input["auto_index_name"] : true;
                    if (!$autoindexname && empty($input["custom_index_name"])) {
                        array_push($validation_errors, '"custom_index_name" required');
                    } elseif (!empty($input["custom_index_name"])) {
                        $customindexname = test_input($input["custom_index_name"]);
                        // check index name is valid
                        if (
                            substr($customindexname, 0, 9) !== 'diskover-' ||
                            preg_match('/([A-G]|[I-L]|[N-R]|[T-X]|Z)/', $customindexname) ||
                            preg_match('/(\\\|\\/|\*|\?|"|<|>|\|| |\,|\#)/', $customindexname) ||
                            strlen($customindexname) > 255 ||
                            strlen($customindexname) < 10
                        ) {
                            array_push($validation_errors, '"custom_index_name" is invalid');
                        }
                    }
                    $overwriteindex = isset($input["overwrite_index"]) ? $input["overwrite_index"] : false;
                    $addtoindex = (isset($input["add_to_index"])) ? $input["add_to_index"] : false;
                    if ($addtoindex && empty($input["custom_index_name"])) {
                        array_push($validation_errors, '"custom_index_name" is required when "add_to_index" given');
                    }
                    $usedefaultconfig = isset($input["use_default_config"]) ? $input["use_default_config"] : true;
                    if (!$usedefaultconfig && empty($input["alt_config_file"])) {
                        array_push($validation_errors, '"alt_config_file" is required');
                    } elseif (!empty($input["alt_config_file"])) {
                        $altconfig = test_input($input["alt_config_file"]);
                        $usedefaultconfig = false;
                    }


                    $newtask = [
                        "id" => md5(uniqid(rand(), true)),
                        "type" => "index",
                        "name" => $name,
                        "description" => $desc,
                        "crawl_paths" => $paths,
                        "alt_scanner" => $altscanner,
                        "cli_options" => $clioptions,
                        "auto_index_name" => $autoindexname,
                        "custom_index_name" => $customindexname,
                        "overwrite_existing" => $overwriteindex,
                        "add_to_index" => $addtoindex,
                        "use_default_config" => $usedefaultconfig,
                        "alt_config_file" => $altconfig,
                        "run_min" => $schedulemin,
                        "run_hour" => $schedulehour,
                        "run_day_month" => $scheduledayofmonth,
                        "run_month" => $schedulemonth,
                        "run_day_week" => $scheduledayofweek,
                        "env_vars" => $envvars,
                        "pre_command" => $precommand,
                        "pre_command_args" => $precommandargs,
                        "post_command" => $postcommand,
                        "post_command_args" => $postcommandargs,
                        "retries" => $retries,
                        "retry_delay" => $retrydelay,
                        "last_start_time" => null,
                        "last_finish_time" => null,
                        "last_success_finish_time" => null,
                        "last_update_time" => gmdate("Y-m-d\TH:i:s"),
                        "last_status" => null,
                        "last_worker" => null,
                        "assigned_worker" => $assignedworker,
                        "email" => $email,
                        "disabled" => $disabled,
                        "timeout" => $timeout,
                        "run_now" => $run_now,
                        "last_error" => null
                    ];
                //
                // its a CUSTOM task
                //
                } else if (strtolower($task_type) == 'custom') {
                    $runcommand = $input["run_command"];
                    if (empty($input["run_command"])) {
                        array_push($validation_errors, '"run_command" is required');
                    }
                    $runcommandargs = $input["run_command_args"];
                    $newtask = [
                        "id" => md5(uniqid(rand(), true)),
                        "type" => "custom",
                        "name" => $name,
                        "description" => $desc,
                        "run_min" => $schedulemin,
                        "run_hour" => $schedulehour,
                        "run_day_month" => $scheduledayofmonth,
                        "run_month" => $schedulemonth,
                        "run_day_week" => $scheduledayofweek,
                        "env_vars" => $envvars,
                        "pre_command" => $precommand,
                        "pre_command_args" => $precommandargs,
                        "run_command" => $runcommand,
                        "run_command_args" => $runcommandargs,
                        "post_command" => $postcommand,
                        "post_command_args" => $postcommandargs,
                        "retries" => $retries,
                        "retry_delay" => $retrydelay,
                        "last_start_time" => null,
                        "last_finish_time" => null,
                        "last_success_finish_time" => null,
                        "last_update_time" => gmdate("Y-m-d\TH:i:s"),
                        "last_status" => null,
                        "last_worker" => null,
                        "assigned_worker" => $assignedworker,
                        "email" => $email,
                        "disabled" => $disabled,
                        "timeout" => $timeout,
                        "run_now" => $run_now,
                        "last_error" => null
                    ];
                } else {
                    throw new Exception('Invalid task type"'. $task_type. '"');
                }

                # Check for any validation errors!!!
                if (count($validation_errors) > 0 ) {
                    throw new ValidationError(json_encode($validation_errors));
                }

                $filename = 'tasks/tasks.json';

                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $tasks_json = read_file_contents($filename);
                $tasks_arr = array();
                $tasks_arr = json_decode($tasks_json, true);

                foreach ($tasks_arr['tasks'] as $task) {
                    if ($task['name'] == $name) {
                        throw new Exception('Task already exists with name "'. $name. '"');
                    }
                }
                array_push($tasks_arr['tasks'], $newtask);

                $updated_tasks_json = json_encode($tasks_arr, JSON_PRETTY_PRINT);
                unlock_file($file, $filename);

                write_file_contents($filename, $updated_tasks_json);

                // create new task template
                if ($maketemplate) {
                    if (strtolower($task_type) == 'index' ) {
                        $newtemplate = [
                            "id" => md5(uniqid(rand(), true)),
                            "type" => "index",
                            "name" => $templatename,
                            "description" => $desc,
                            "crawl_paths" => $paths,
                            "alt_scanner" => $altscanner,
                            "cli_options" => $clioptions,
                            "auto_index_name" => $autoindexname,
                            "custom_index_name" => $customindexname,
                            "overwrite_existing" => $overwriteindex,
                            "add_to_index" => $addtoindex,
                            "use_default_config" => $usedefaultconfig,
                            "alt_config_file" => $altconfig,
                            "run_min" => $schedulemin,
                            "run_hour" => $schedulehour,
                            "run_day_month" => $scheduledayofmonth,
                            "run_month" => $schedulemonth,
                            "run_day_week" => $scheduledayofweek,
                            "env_vars" => $envvars,
                            "pre_command" => $precommand,
                            "pre_command_args" => $precommandargs,
                            "post_command" => $postcommand,
                            "post_command_args" => $postcommandargs,
                            "assigned_worker" => $assignedworker,
                            "retries" => $retries,
                            "retry_delay" => $retrydelay,
                            "email" => $email,
                            "timeout" => $timeout,
                        ];
                    } else {
                        $newtemplate = [
                            "id" => md5(uniqid(rand(), true)),
                            "type" => "custom",
                            "name" => $templatename,
                            "description" => $desc,
                            "run_min" => $schedulemin,
                            "run_hour" => $schedulehour,
                            "run_day_month" => $scheduledayofmonth,
                            "run_month" => $schedulemonth,
                            "run_day_week" => $scheduledayofweek,
                            "env_vars" => $envvars,
                            "pre_command" => $precommand,
                            "pre_command_args" => $precommandargs,
                            "run_command" => $runcommand,
                            "run_command_args" => $runcommandargs,
                            "post_command" => $postcommand,
                            "post_command_args" => $postcommandargs,
                            "retries" => $retries,
                            "retry_delay" => $retrydelay,
                            "assigned_worker" => $assignedworker,
                            "email" => $email,
                            "disabled" => $disabled,
                            "timeout" => $timeout
                        ];
                    }
                    $filename = 'tasks/templates.json';

                    $file = fopen($filename, 'r');
                    lock_file($file, $filename);
                    $templates_json = read_file_contents($filename);
                    $templates_arr = json_decode($templates_json, true);

                    // add task to templates.json
                    foreach ($templates_arr['templates'] as $template) {
                        if ($template['name'] == $templatename) {
                            throw new Exception('Template already exists with name "'. $templatename. '"');
                        }
                    }
                    array_push($templates_arr['templates'], $newtemplate);

                    $newtemplates_json = json_encode($templates_arr, JSON_PRETTY_PRINT);
                    unlock_file($file, $filename);

                    write_file_contents($filename, $newtemplates_json);
                }

                // send json response
                echo json_response(200, $newtask);
            } catch (ValidationError $ex) {
                echo json_response(422, '' . $ex);
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        default:
                echo json_response(400, 'unknown api endpoint');
    }
}

function put($endpoint, $input)
{
    global $client, $mnclient, $ldaplogin, $ldapadmin;

    // deny access for non-admin ldap user
    if ($ldaplogin && !$ldapadmin) {
        header('WWW-Authenticate: Basic realm="diskover REST API"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Access Denied! diskover LDAP admin group membership required for PUT.';
        exit;
    }

    switch ($endpoint) {
        // tag directory docs(s) and items in directory
        case $endpoint[1] == 'tagdirs':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                $dirs = $input['dirs'];
                $tags = $input['tags'];
                $recursive = $input['recursive'];
                $tagfiles = $input['tagfiles'];
                $numitems = 0;
                foreach ($dirs as $parent_path) {
                    // first let's get the directory doc id
                    $searchParams = [];
                    // which index to search
                    $searchParams['index'] = $endpoint[0];
                    // which client to use
                    try {
                        $client = $mnclient->getClientByIndex($endpoint[0]);
                    } catch (Exception $ex) {
                        echo json_response(500, 'es error ' . $ex->getMessage());
                        die();
                    }
                    if (is_null($client)) {
                        echo json_response(404, 'es index not found');
                        die();
                    }
                    $results = [];
                    $queryResponse = [];

                    $searchParams['size'] = 1;

                    // esccape special characters
                    $pp = addcslashes(getDirName($parent_path), '<>+-&|!(){}[]^"~*?:/= @\'$.#\\');
                    $f = addcslashes(basename($parent_path), '<>+-&|!(){}[]^"~*?:/= @\'$.#\\');

                    $searchParams['body'] = [
                        '_source' => ['tags'],
                        'query' => [
                            'query_string' => [
                                'query' => 'parent_path:' . $pp . ' AND name:' . $f . ' AND type:"directory"'
                            ]
                        ]
                    ];

                    try {
                        // Send search query to Elasticsearch
                        $queryResponse = $client->search($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                        die();
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    // check if directory found
                    if (!$queryResponse['hits']['hits']) {
                        continue;
                    }

                    // store the directory doc data
                    $directory_hit = $queryResponse['hits']['hits'][0];

                    // add directory doc data to results
                    $results[] = $directory_hit;

                    // now let's get all the doc id's in the directory

                    if ($recursive === "true" || $tagfiles === "true") {
                        $queryResponse = [];

                        // Scroll parameter alive time
                        $searchParams['scroll'] = "30s";

                        // scroll size
                        $searchParams['size'] = 1000;

                        $pp = addcslashes($parent_path, '+-&|!(){}[]^"~*?:\/ ');

                        if ($recursive === "true") {
                            $type = ($tagfiles === "true") ? '(file OR directory)' : 'directory';
                            $searchParams['body'] = [
                                '_source' => ['tags'],
                                'query' => [
                                    'query_string' => [
                                        'query' => 'parent_path:' . $pp . '* AND type:' . $type,
                                        'analyze_wildcard' => 'true'
                                    ]
                                ]
                            ];
                        } elseif ($tagfiles === "true") {
                            $searchParams['body'] = [
                                '_source' => ['tags'],
                                'query' => [
                                    'query_string' => [
                                        'query' => 'parent_path:' . $pp . ' AND type:"file"',
                                        'analyze_wildcard' => 'true'
                                    ]
                                ]
                            ];
                        }

                        try {
                            // Send search query to Elasticsearch
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                            die();
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        // set total hits
                        $total = $queryResponse['hits']['total']['value'];

                        $i = 1;
                        // Loop through all the pages of results
                        while ($i <= ceil($total / $searchParams['size'])) {
                            // add files in directory to results array
                            foreach ($queryResponse['hits']['hits'] as $hit) {
                                $results[] = $hit;
                            }

                            $scroll_id = $queryResponse['_scroll_id'];

                            $queryResponse = $client->scroll([
                                "body" => [
                                    "scroll_id" => $scroll_id,
                                    "scroll" => "30s"
                                ]
                            ]);

                            $i += 1;
                        }
                    }

                    // loop through all the items in results and update tag(s)

                    foreach ($results as $r) {
                        $searchParams = [];
                        $queryResponse = [];

                        // get id and index of file
                        $id = $r['_id'];
                        $index = $r['_index'];

                        $searchParams = array();
                        $searchParams['id'] = $id;
                        $searchParams['index'] = $index;

                        try {
                            $queryResponse = $client->get($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                            die();
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        if (isset($tags) && count($tags) > 0) {
                            foreach ($tags as $tag) {
                                if ($r['_source']['tags']) {
                                    // clear same tag
                                    if (array_search($tag, $r['_source']['tags']) !== false) {
                                        $key = array_search($tag, $r['_source']['tags']);
                                        unset($queryResponse['_source']['tags'][$key]);
                                    }
                                    // add tag
                                    else {
                                        $queryResponse['_source']['tags'][] = $tag;
                                    }
                                    // add tag
                                } else {
                                    $queryResponse['_source']['tags'][] = $tag;
                                }
                            }
                            $queryResponse['_source']['tags'] = array_values($queryResponse['_source']['tags']);
                        }
                        // clear all tags
                        else {
                            $queryResponse['_source']['tags'] = [];
                        }

                        $searchParams['body']['doc'] = $queryResponse['_source'];

                        try {
                            $queryResponse = $client->update($searchParams);
                            $numitems += 1;
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                            die();
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }
                    }
                }
                // send json response
                echo json_response(200, $numitems . ' directory docs updated');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

            // tag files
        case $endpoint[1] == 'tagfiles':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                $files = $input['files'];
                $tags = $input['tags'];
                $numfiles = 0;

                // update existing tag field with new value
                foreach ($files as $f) {
                    $searchParams = [];
                    // which index to search
                    $searchParams['index'] = $endpoint[0];
                    // which client to use
                    try {
                        $client = $mnclient->getClientByIndex($endpoint[0]);
                    } catch (Exception $ex) {
                        echo json_response(500, 'es error ' . $ex->getMessage());
                        die();
                    }
                    if (is_null($client)) {
                        echo json_response(404, 'es index not found');
                        die();
                    }
                    $queryResponse = [];
                    $parent_path = getDirName($f);
                    $name = basename($f);

                    $searchParams['body'] = [
                        '_source' => ['tags'],
                        'query' => [
                            'query_string' => [
                                'query' => 'parent_path:"' . $parent_path . '" AND name:"' . $name . '" AND type:"file"'
                            ]
                        ]
                    ];

                    try {
                        // Send search query to Elasticsearch
                        $queryResponse = $client->search($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                        die();
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    // check if any files found
                    if (!$queryResponse['hits']['hits']) {
                        continue;
                    }

                    // get id and index of file
                    $id = $queryResponse['hits']['hits'][0]['_id'];
                    $index = $queryResponse['hits']['hits'][0]['_index'];

                    $searchParams = array();
                    $searchParams['id'] = $id;
                    $searchParams['index'] = $index;

                    try {
                        $queryResponse = $client->get($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                        die();
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    if (isset($tags) && count($tags) > 0) {
                        foreach ($tags as $tag) {
                            if ($queryResponse['_source']['tags']) {
                                // clear same tag
                                if (array_search($tag, $queryResponse['_source']['tags']) !== false) {
                                    $key = array_search($tag, $queryResponse['_source']['tags']);
                                    unset($queryResponse['_source']['tags'][$key]);
                                }
                                // add tag
                                else {
                                    $queryResponse['_source']['tags'][] = $tag;
                                }
                                // add tag
                            } else {
                                $queryResponse['_source']['tags'][] = $tag;
                            }
                        }
                        $queryResponse['_source']['tags'] = array_values($queryResponse['_source']['tags']);
                    }
                    // clear all tags
                    else {
                        $queryResponse['_source']['tags'] = [];
                    }

                    $searchParams['body']['doc'] = $queryResponse['_source'];

                    try {
                        $queryResponse = $client->update($searchParams);
                        $numfiles += 1;
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                        die();
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }
                }
                // send json response
                echo json_response(200, $numfiles . ' file docs updated');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;


            // =============== TASKS API START ===============

        case $endpoint[0] == 'updatetask':
            $validation_errors = array();

            try {
                $time_utc = gmdate("Y-m-d\TH:i:s");
                $task_id = $input['id'];
                $worker = $input['worker'];
                $status = $input['status'];
                $start_time = $input['start_time'];
                $finish_time = $input['finish_time'];
                $success_finish_time = $input['success_finish_time'];
                $error = $input['error'];

                $run_now = $input['run_now'];
                if (!empty($run_now) && is_bool($run_now) === false) {
                    array_push($validation_errors, '"run_now" nust be a boolean value');
                }
                $stop_task = $input['stop_task'];
                if (!empty($stop_task) && is_bool($stop_task) === false) {
                    array_push($validation_errors, '"stop_task" nust be a boolean value');
                }
                $stop_task_force = $input['stop_task_force'];
                if (!empty($stop_task_force) && is_bool($stop_task_force) === false) {
                    array_push($validation_errors, '"stop_task_force" nust be a boolean value');
                }
                $disabled = $input['disabled'];
                if (!empty($disabled) && is_bool($disabled) === false) {
                    array_push($validation_errors, '"disabled" nust be a boolean value');
                }

                # Check for any validation errors!!!
                if (count($validation_errors) > 0 ) {
                    throw new ValidationError(json_encode($validation_errors));
                }

                $filename = 'tasks/tasks.json';
                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $tasks_json = read_file_contents($filename);
                $tasks_arr = json_decode($tasks_json, true);

                // update tasks_arr for json file update
                foreach ($tasks_arr['tasks'] as $key => $entry) {
                    if ($entry['id'] == $task_id) {
                        $tasks_arr['tasks'][$key]['last_worker'] = $worker;
                        if (!empty($start_time)) {
                            $tasks_arr['tasks'][$key]['last_start_time'] = $start_time;
                            $tasks_arr['tasks'][$key]['last_finish_time'] = null;
                        }
                        if (!empty($finish_time)) {
                            $tasks_arr['tasks'][$key]['last_finish_time'] = $finish_time;
                        }
                        if (!empty($success_finish_time)) {
                            $tasks_arr['tasks'][$key]['last_success_finish_time'] = $success_finish_time;
                        }
                        $tasks_arr['tasks'][$key]['run_now'] = $run_now;
                        $tasks_arr['tasks'][$key]['last_update_time'] = $time_utc;
                        $tasks_arr['tasks'][$key]['last_status'] = $status;
                        $tasks_arr['tasks'][$key]['stop_task'] = $stop_task;
                        $tasks_arr['tasks'][$key]['stop_task_force'] = $stop_task_force;
                        if (isset($disabled)) {
                            $tasks_arr['tasks'][$key]['disabled'] = $disabled;
                        }
                        $tasks_arr['tasks'][$key]['last_error'] = $error;
                        break;
                    }
                }

                $updated_tasks_json = json_encode($tasks_arr, JSON_PRETTY_PRINT);
                unlock_file($file);

                write_file_contents($filename, $updated_tasks_json);

                // send json response
                echo json_response(200, 'task updated');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'updateworker':
            try {
                $time_utc = gmdate("Y-m-d\TH:i:s");
                $name = $input['name'];
                $hostname = $input['hostname'];
                $user = $input['user'];
                $pid = $input['pid'];
                $state = $input['state'];
                $current_tasks = $input['current_tasks'];
                $successful_task_count = $input['successful_task_count'];
                $failed_task_count = $input['failed_task_count'];
                $total_working_time = $input['total_working_time'];
                $total_running_time = $input['total_running_time'];
                $load_avg = $input['load_avg'];
                $worker_pools = $input['worker_pools'];
                $diskover_ver = $input['diskover_ver'];
                $diskoverd_ver = $input['diskoverd_ver'];

                $filename = 'tasks/workers.json';
                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $workers_json = read_file_contents($filename);
                $workers_arr = json_decode($workers_json, true);

                // update workers_arr for json file update
                $worker_found = false;
                foreach ($workers_arr['workers'] as $key => $entry) {
                    if ($entry['name'] == $name) {
                        $worker_found = true;
                        $workers_arr['workers'][$key]['hostname'] = $hostname;
                        $workers_arr['workers'][$key]['pid'] = $pid;
                        $workers_arr['workers'][$key]['user'] = $user;
                        $workers_arr['workers'][$key]['state'] = $state;
                        $workers_arr['workers'][$key]['current_tasks'] = $current_tasks;
                        $workers_arr['workers'][$key]['last_heartbeat'] = $time_utc;
                        if (!is_null($successful_task_count)) $workers_arr['workers'][$key]['successful_task_count'] = $successful_task_count;
                        if (!is_null($failed_task_count)) $workers_arr['workers'][$key]['failed_task_count'] = $failed_task_count;
                        if (!is_null($total_working_time)) $workers_arr['workers'][$key]['total_working_time'] = $total_working_time;
                        if (!is_null($total_running_time)) $workers_arr['workers'][$key]['total_running_time'] = $total_running_time;
                        if (!is_null($load_avg)) $workers_arr['workers'][$key]['load_avg'] = $load_avg;
                        if (!is_null($worker_pools)) $workers_arr['workers'][$key]['worker_pools'] = $worker_pools;
                        if (!is_null($diskover_ver)) $workers_arr['workers'][$key]['diskover_ver'] = $diskover_ver;
                        if (!is_null($diskoverd_ver)) $workers_arr['workers'][$key]['diskoverd_ver'] = $diskoverd_ver;
                        break;
                    }
                }

                // add new worker if not found
                if (!$worker_found) {
                    $worker_arr = array();
                    $worker_arr['name'] = $name;
                    $worker_arr['hostname'] = $hostname;
                    $worker_arr['pid'] = $pid;
                    $worker_arr['user'] = $user;
                    $worker_arr['state'] = $state;
                    $worker_arr['disabled'] = false;
                    $worker_arr['current_tasks'] = $current_tasks;
                    $worker_arr['last_heartbeat'] = $time_utc;
                    $worker_arr['birth_date'] = $time_utc;
                    $worker_arr['successful_task_count'] = 0;
                    $worker_arr['failed_task_count'] = 0;
                    $worker_arr['total_working_time'] = 0;
                    $worker_arr['load_avg'] = $load_avg;
                    $worker_arr['worker_pools'] = $worker_pools;
                    $worker_arr['diskover_ver'] = $diskover_ver;
                    $worker_arr['diskoverd_ver'] = $diskoverd_ver;
                    $workers_arr['workers'][] = $worker_arr;
                }

                $updated_workers_json = json_encode($workers_arr, JSON_PRETTY_PRINT);
                unlock_file($file);

                write_file_contents($filename, $updated_workers_json);

                // send json response
                echo json_response(200, 'worker updated');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'heartbeat':
            try {
                $time_utc = gmdate("Y-m-d\TH:i:s");
                $name = $input['name'];

                $filename = 'tasks/workers.json';
                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $workers_json = read_file_contents($filename);
                $workers_arr = json_decode($workers_json, true);

                // update json file
                foreach ($workers_arr['workers'] as $key => $entry) {
                    if ($entry['name'] == $name) {
                        $workers_arr['workers'][$key]['last_heartbeat'] = $time_utc;
                        break;
                    }
                }

                $updated_workers_json = json_encode($workers_arr, JSON_PRETTY_PRINT);
                unlock_file($file);

                write_file_contents($filename, $updated_workers_json);

                // send json response
                echo json_response(200, 'heartbeat received');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'tasklog':
            try {
                $time_utc = gmdate("Y-m-d\TH:i:s");
                $task_id = $input['task_id'];
                $task_name = $input['task_name'];
                $task_type = $input['task_type'];
                $worker = $input['worker'];
                $start_time = $input['start_time'];
                $finish_time = $input['finish_time'];
                $task_time = $input['task_time'];
                $status = $input['status'];
                $error = $input['error'];

                $filename = 'tasks/tasklog.json';
                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $tasklog_json = read_file_contents($filename);
                $tasklog_arr = json_decode($tasklog_json, true);

                // update json file
                $tasklog_arr[] = [
                    'date' => $time_utc,
                    'task_name' => $task_name,
                    'task_type' => $task_type,
                    'worker' => $worker,
                    'start_time' => $start_time,
                    'finish_time' => $finish_time,
                    'task_time' => $task_time,
                    'status' => $status,
                    'error' => $error
                ];

                $updated_tasklog_json = json_encode($tasklog_arr, JSON_PRETTY_PRINT);
                unlock_file($file);

                write_file_contents($filename, $updated_tasklog_json);

                // send json response
                echo json_response(200, 'task log entry added');
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

            // =============== TASKS API END ===============

        default:
            echo json_response(400, 'unknown api endpoint');
    }
}

function get($endpoint, $query)
{
    global $mnclient, $client, $ldaplogin, $ldapadmin;

    // parse query string into vars
    parse_str($query, $output);

    // deny access for certain endpoints for non-admin ldap user
    if ($ldaplogin && !$ldapadmin) {
        $allowed_endpoints = array('search');
        if (!in_array($endpoint[1], $allowed_endpoints)) {
            header('WWW-Authenticate: Basic realm="diskover REST API"');
            header('HTTP/1.0 403 Forbidden');
            echo "API endpoint \"$endpoint[1]\" not allowed for non-admin LDAP user. Allowed endpoints: " . implode(', ', $allowed_endpoints);
            exit;
        }
    }

    switch ($endpoint) {

        case $endpoint[1] == 'tagcount':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // which type within the index to search
                $type = (isset($output['type'])) ? $output['type'] : '(file OR directory)';
                $tagCountRes = 0;
                if (isset($output['tag'])) {
                    if ($output['tag']) {
                        $searchParams['body'] = [
                            'size' => 0,
                            'query' => [
                                'query_string' => [
                                    'query' => 'tags:"' . $output['tag'] . '" AND type:' . $type
                                ]
                            ]
                        ];
                    } else {
                        echo json_response(400, 'missing tag');
                        die();
                    }

                    // Get search results from Elasticsearch for tag
                    try {
                        // Send search query to Elasticsearch
                        $queryResponse = $client->search($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                        die();
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    // Get total for tag
                    $tagCount = $queryResponse['hits']['total']['value'];
                    $tagCountRes = $$tagCount;
                } else {
                    // Grab all the custom tags from file and add to tagCounts
                    $customtags = get_custom_tags();
                    $tagCountsCustom = [];
                    foreach ($customtags as $tag) {
                        $tagCountsCustom[$tag[0]] = 0;
                    }

                    foreach ($tagCountsCustom as $tag => $value) {
                        $searchParams['body'] = [
                            'size' => 0,
                            'query' => [
                                'query_string' => [
                                    'query' => 'tags:"' . $tag . '" AND type:' . $type
                                ]
                            ]
                        ];

                        try {
                            // Send search query to Elasticsearch
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                            die();
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        // Get total for tag
                        $tagCountsCustom[$tag] = $queryResponse['hits']['total']['value'];
                    }
                    $tagCountRes = $tagCountsCustom;
                }

                // send json response
                echo json_response(200, array('data' => $tagCountRes));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'tagsize':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // which type within the index to search
                $type = (isset($output['type'])) ? $output['type'] : '(file OR directory)';
                $tagSizesRes = 0;
                if (isset($output['tag'])) {
                    if ($output['tag']) {
                        $searchParams['body'] = [
                            'size' => 0,
                            'query' => [
                                'query_string' => [
                                    'query' => 'tags:"' . $output['tag'] . '" AND type:' . $type
                                ]
                            ],
                            'aggs' => [
                                'total_size' => [
                                    'sum' => [
                                        'field' => 'size'
                                    ]
                                ]
                            ]
                        ];
                    } else {
                        echo json_response(400, 'missing tag');
                        die();
                    }

                    // Get search results from Elasticsearch for tag
                    $tagSize = 0;

                    try {
                        // Send search query to Elasticsearch
                        $queryResponse = $client->search($searchParams);
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                        die();
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }

                    // Get total for tag
                    $tagSize = $queryResponse['aggregations']['total_size']['value'];
                    $tagSizesRes = $tagSize;
                } else {
                    // Grab all the custom tags from file and add to tagSizesCustom
                    $customtags = get_custom_tags();
                    $tagSizesCustom = [];
                    foreach ($customtags as $tag) {
                        $tagSizesCustom[$tag[0]] = 0;
                    }

                    foreach ($tagSizesCustom as $tag => $value) {
                        $searchParams['body'] = [
                            'size' => 0,
                            'query' => [
                                'query_string' => [
                                    'query' => 'tags:"' . $tag . '" AND type:' . $type
                                ]
                            ],
                            'aggs' => [
                                'total_size' => [
                                    'sum' => [
                                        'field' => 'size'
                                    ]
                                ]
                            ]
                        ];

                        try {
                            // Send search query to Elasticsearch
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                            die();
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        // Get total size of all files with tag
                        $tagSizesCustom[$tag] = $queryResponse['aggregations']['total_size']['value'];
                    }
                    $tagSizesRes = $tagSizesCustom;
                }

                // send json response
                echo json_response(200, array('data' => $tagSizesRes));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'tags':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // which type within the index to search
                $type = (isset($output['type'])) ? $output['type'] : '(file OR directory)';
                // Scroll parameter alive time
                $searchParams['scroll'] = "30s";

                // scroll size
                $searchParams['size'] = (isset($output['size']) ? $output['size'] : 1000);

                // page number of results to print
                $page = (isset($output['page']) ? $output['page'] : 1);

                if (empty($output['tag'])) {
                    $searchParams['body'] = [
                        'query' => [
                            'query_string' => [
                                'query' => 'NOT tags:* AND type:' . $type
                            ]
                        ]
                    ];
                } else {
                    $searchParams['body'] = [
                        'query' => [
                            'query_string' => [
                                'query' => 'tags:"' . $output['tag'] . '" AND type:' . $type
                            ]
                        ]
                    ];
                }

                // Send search query to Elasticsearch and get scroll id and first page of results
                try {
                    // Send search query to Elasticsearch
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                    die();
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                // set total hits
                $total = $queryResponse['hits']['total']['value'];

                $i = 1;
                $results = [];
                // Loop through all the pages of results
                while ($i <= ceil($total / $searchParams['size'])) {
                    // check if we have the results for the page we are on
                    if ($i == $page) {
                        // Get files for tag
                        $results[$i] = $queryResponse['hits']['hits'];
                        // end loop
                        break;
                    }

                    $scroll_id = $queryResponse['_scroll_id'];

                    // Execute a Scroll request and repeat
                    $queryResponse = $client->scroll([
                        "body" => [
                            "scroll_id" => $scroll_id,
                            "scroll" => "30s"
                        ]
                    ]);

                    $i += 1;
                }

                // send json response
                if ($results[$page]) {
                    echo json_response(200, array('totalhits' => $total, 'data' => $results[$page]));
                } else {
                    echo json_response(200, array('totalhits' => $total, 'data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex->getMessage());
            }
            break;

        case $endpoint[0] == 'list':
            try {
                $clients = $mnclient->getClients();
                $diskover_indices_all = array();
                foreach ($clients as $client) {
                    try {
                        $diskover_indices = $client->cat()->indices(array('index' => 'diskover-*'));
                    } catch (Missing404Exception $e) {
                        echo json_response(404, 'es index not found ' . $e->getMessage());
                        die();
                    } catch (Exception $e) {
                        echo json_response(500, 'es error ' . $e->getMessage());
                        die();
                    }
                    for ($i = 0; $i < count($diskover_indices); $i++) {
                        // Get search results from Elasticsearch for index/space info
                        $results = [];
                        $searchParams = [];
                        // Setup search query
                        $searchParams['index'] = $diskover_indices[$i]['index'];
                        $searchParams['body'] = [
                            'size' => 100,
                            'query' => [
                                'match' => ['type' => 'indexinfo']
                            ]
                        ];
                        try {
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            echo json_response(404, 'es index not found ' . $e->getMessage());
                            die();
                        } catch (Exception $e) {
                            echo json_response(500, 'es error ' . $e->getMessage());
                            die();
                        }

                        $paths = [];

                        foreach ($queryResponse['hits']['hits'] as $hit) {
                            if (!in_array($hit['_source']['path'], $paths)) {
                                $paths[] = $hit['_source']['path'];
                            }
                            $x = array_search($hit['_source']['path'], $paths);
                            if (isset($hit['_source']['path'])) {
                                $diskover_indices[$i][$x]['path'] = $hit['_source']['path'];
                            }
                            if (isset($hit['_source']['file_count'])) {
                                $diskover_indices[$i][$x]['totalfiles'] = $hit['_source']['file_count'];
                            }
                            if (isset($hit['_source']['dir_count'])) {
                                $diskover_indices[$i][$x]['totaldirs'] = $hit['_source']['dir_count'];
                            }
                            if (isset($hit['_source']['file_size'])) {
                                $diskover_indices[$i][$x]['totalSize'] = $hit['_source']['file_size'];
                            }
                            if (isset($hit['_source']['file_size_du'])) {
                                $diskover_indices[$i][$x]['totalSizeDu'] = $hit['_source']['file_size_du'];
                            }
                            if (isset($hit['_source']['start_at'])) {
                                $diskover_indices[$i][$x]['crawlStartTime'] = $hit['_source']['start_at'];
                            }
                            if (isset($hit['_source']['end_at'])) {
                                $diskover_indices[$i][$x]['crawlEndTime'] = $hit['_source']['end_at'];
                            }
                            if (isset($hit['_source']['crawl_time'])) {
                                $diskover_indices[$i][$x]['elapsedCrawlTime'] = round($hit['_source']['crawl_time'], 6);
                            }
                        }

                        // get total hardlink count and size for each path in index
                        $x = 0;
                        foreach ($paths as $p) {
                            $searchParams['body'] = [
                                'size' => 0,
                                'track_total_hits' => true,
                                'aggs' => [
                                    'total_size' => [
                                        'sum' => [
                                            'field' => 'size'
                                        ]
                                    ]
                                ],
                                'query' => [
                                    'query_string' => [
                                        'query' => 'parent_path:' . escape_chars($p) . '* AND nlink:>1 AND type:"file"',
                                        'analyze_wildcard' => 'true'
                                    ]
                                ]
                            ];
                            try {
                                // Send search query to Elasticsearch
                                $queryResponse = $client->search($searchParams);
                            } catch (Missing404Exception $e) {
                                echo json_response(404, 'es index not found ' . $e->getMessage());
                                die();
                            } catch (Exception $e) {
                                echo json_response(500, 'es error ' . $e->getMessage());
                                die();
                            }

                            $diskover_indices[$i][$x]['totalHardlinkFiles'] = $queryResponse['hits']['total']['value'];
                            $diskover_indices[$i][$x]['totalHardlinkSize'] = $queryResponse['aggregations']['total_size']['value'];
                            $x += 1;
                        }
                    }
                    $diskover_indices_all = array_merge($diskover_indices_all, $diskover_indices);
                }
                // send json response
                echo json_response(200, array('data' => $diskover_indices_all));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'diskspace':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                $diskover_indices = [];
                $searchParams = [];
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // Get search results from Elasticsearch for disk space info
                $searchParams['body'] = [
                    'size' => 100,
                    'query' => [
                        'match' => ['type' => 'spaceinfo']
                    ]
                ];
                try {
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                    die();
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                $paths = [];

                foreach ($queryResponse['hits']['hits'] as $hit) {
                    if (!in_array($hit['_source']['path'], $paths)) {
                        $paths[] = $hit['_source']['path'];
                    }
                    $x = array_search($hit['_source']['path'], $paths);
                    if (isset($hit['_source']['path'])) {
                        $diskover_indices[$x]['path'] = $hit['_source']['path'];
                    }
                    if (isset($hit['_source']['total'])) {
                        $diskover_indices[$x]['totalSize'] = $hit['_source']['total'];
                    }
                    if (isset($hit['_source']['used'])) {
                        $diskover_indices[$x]['usedSize'] = $hit['_source']['used'];
                    }
                    if (isset($hit['_source']['free'])) {
                        $diskover_indices[$x]['freeSize'] = $hit['_source']['free'];
                    }
                    if (isset($hit['_source']['free_percent'])) {
                        $diskover_indices[$x]['freePercent'] = $hit['_source']['free_percent'];
                    }
                    if (isset($hit['_source']['available'])) {
                        $diskover_indices[$x]['availableSize'] = $hit['_source']['available'];
                    }
                    if (isset($hit['_source']['available_percent'])) {
                        $diskover_indices[$x]['availablePercent'] = $hit['_source']['available_percent'];
                    }
                }

                // send json response
                echo json_response(200, array('data' => $diskover_indices));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'search':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search
                // Scroll parameter alive time
                $searchParams['scroll'] = "30s";

                // scroll size
                $searchParams['size'] = (isset($output['size']) ? $output['size'] : 1000);

                // page number of results to print
                $page = (isset($output['page']) ? $output['page'] : 1);

                $searchParams['body'] = [
                    'query' => [
                        'query_string' => [
                            'query' => $output['query'],
                            'analyze_wildcard' => 'true'
                        ]
                    ]
                ];
                
                // apply any filters to search for non-admin ldap user
                if ($ldaplogin && !$ldapadmin) {
                    $searchParams = filterIndexMappingPaths($searchParams);
                    $searchParams = filterLDAPGroups($searchParams);
                }

                // Send search query to Elasticsearch and get scroll id and first page of results
                try {
                    // Send search query to Elasticsearch
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                    die();
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                // set total hits
                $total = $queryResponse['hits']['total']['value'];

                $i = 1;
                $results = [];
                // Loop through all the pages of results and store in results array
                while ($i <= ceil($total / $searchParams['size'])) {
                    // check if we have the results for the page we are on
                    if ($i == $page) {
                        // Get results for page
                        $results[$i] = $queryResponse['hits']['hits'];
                        // end loop
                        break;
                    }

                    $scroll_id = $queryResponse['_scroll_id'];

                    $queryResponse = $client->scroll([
                        "body" => [
                            "scroll_id" => $scroll_id,
                            "scroll" => "30s"
                        ]
                    ]);

                    $i += 1;
                }

                // send json response
                if ($results[$page]) {
                    echo json_response(200, array('totalhits' => $total, 'data' => $results[$page]));
                } else {
                    echo json_response(200, array('totalhits' => $total, 'data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'toppaths':
            # get all top paths in an index
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                // Setup search query for es index searches
                $searchParams['index'] = $endpoint[0]; // which index to search

                $searchParams['size'] = 100;

                $searchParams['body'] = [
                    '_source' => ['path'],
                    'query' => [
                        'match' => [
                            'type' => 'indexinfo'
                        ]
                    ]
                ];

                try {
                    // Send search query to Elasticsearch
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                    die();
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                $results = $queryResponse['hits']['hits'];
                $toppaths = array();
                foreach ($results as $res) {
                    $toppaths[] = $res['_source']['path'];
                }
                $toppaths = array_unique($toppaths);

                // send json response
                echo json_response(200, array('data' => $toppaths));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'latest':
            # get latest index from top path
            if (isset($output['toppath'])) {
                $toppath = $output['toppath'];
            } else {
                echo json_response(400, 'missing toppath');
                die();
            }
            try {
                // refresh indices
                $mnclient->refreshIndices();
                // get all diskover indices info
                $diskover_indices = $mnclient->getIndicesInfoCurl();
                // add all top paths in indices to index_toppaths
                $index_toppaths = [];
                $disabled_indices = [];
                $indices_sorted = [];

                foreach ($diskover_indices as $esnode => $esindices) {
                    foreach ($esindices as $key => $val) {
                        // Get search results from Elasticsearch for indexinfo docs
                        $results = [];
                        $searchParams = [];
                        // Setup search query
                        $searchParams['index'] = $key;
                        $searchParams['body'] = [
                            'size' => 100,
                            'query' => [
                                'match' => ['type' => 'indexinfo']
                            ],
                            'sort' => ['start_at' => 'asc']
                        ];
                        try {
                            $queryResponse = $client->search($searchParams);
                        } catch (Missing404Exception $e) {
                            continue;
                        } catch (Exception $e) {
                            continue;
                        }

                        $startcount = 0;
                        $endcount = 0;
                        foreach ($queryResponse['hits']['hits'] as $hit) {
                            if (array_key_exists('start_at', $hit['_source'])) {
                                $startcount += 1;
                            }
                            if (array_key_exists('end_at', $hit['_source'])) {
                                $endcount += 1;
                            }
                            if (
                                array_key_exists($key, $index_toppaths) &&
                                !in_array($hit['_source']['path'], $index_toppaths[$key])
                            ) {
                                $index_toppaths[$key][] = $hit['_source']['path'];
                            } else {
                                $index_toppaths[$key] = array($hit['_source']['path']);
                            }
                        }
                        // add to disabled_indices list if still being indexed
                        if ($endcount < $startcount) {
                            $disabled_indices[] = $key;
                        }

                        // add to indices_sorted using creation_date as key
                        $indices_sorted[$diskover_indices[$esnode][$key]['creation_date']] = [
                            'index' => $key,
                            'esnode' => $esnode
                        ];
                    }
                }

                // sort completed indices by creation_date
                krsort($indices_sorted);

                // get latest index
                $latest_index = null;
                foreach ($indices_sorted as $key => $val) {
                    if (!in_array($val['index'], $disabled_indices)) {
                        // get all top paths in index and check for toppath match
                        foreach($index_toppaths[$val['index']] as $index_toppath) {
                            if ($index_toppath == $toppath) {
                                $latest_index = $val['index'];
                                break 2;
                            }
                        }
                    }
                }

                // send json response
                echo json_response(200, array('data' => $latest_index));
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

            // =============== TASKS API START ===============

        case $endpoint[0] == 'tasks':
            try {
                // read json file and get tasks
                $filename = "tasks/tasks.json";
                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $tasks_json = read_file_contents($filename);
                unlock_file($file);
                $tasks_arr = json_decode($tasks_json, true);

                // send json response
                if ($tasks_arr) {
                    echo json_response(200, array('data' => $tasks_arr));
                } else {
                    echo json_response(200, array('data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'workers':
            try {
                // read json file and get workers
                $filename = "tasks/workers.json";
                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $workers_json = read_file_contents($filename);
                unlock_file($file);
                $workers_arr = json_decode($workers_json, true);
 
                // send json response
                if ($workers_arr) {
                    echo json_response(200, array('data' => $workers_arr));
                } else {
                    echo json_response(200, array('data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[0] == 'workerinfo':
            try {
                $name = $output['worker'];
                // read json file and get workers
                $filename = "tasks/workers.json";
                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $workers_json = read_file_contents($filename);
                unlock_file($file);
                $workers_arr = json_decode($workers_json, true);

                $worker_info = array();
                foreach ($workers_arr['workers'] as $key => $entry) {
                    if ($entry['name'] == $name) {
                        $worker_info = $workers_arr['workers'][$key];
                        break;
                    }
                }

                // send json response
                if ($worker_info) {
                    echo json_response(200, array('data' => $worker_info));
                } else {
                    echo json_response(200, array('data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        case $endpoint[1] == 'worker4index':
            try {
                if (count($endpoint) < 2) {
                    echo json_response(400, 'missing index');
                    die();
                }
                $index = $endpoint[0]; // which index do we want the worker for?

                //Query indexinfo docs for the index and get the hostname
                $results = [];
                $searchParams = [];
                // Setup search query
                $searchParams['index'] = $index;
                $searchParams['body'] = [
                    'size' => 100,
                    'query' => [
                        'match' => ['type' => 'indexinfo']
                    ],
                    'sort' => ['start_at' => 'asc']
                ];
                try {
                    $queryResponse = $client->search($searchParams);
                } catch (Missing404Exception $e) {
                    echo json_response(404, 'es index not found ' . $e->getMessage());
                    die();
                } catch (Exception $e) {
                    echo json_response(500, 'es error ' . $e->getMessage());
                    die();
                }

                $hostname = null;
                foreach ($queryResponse['hits']['hits'] as $hit) {
                    if (array_key_exists('hostname', $hit['_source'])) {
                        $hostname = $hit['_source']['hostname'];
                        break;
                    }
                }

                $worker_info = array();
                if (!is_null($hostname)) {
                    $filename = "tasks/workers.json";
                    $file = fopen($filename, 'r');
                    lock_file($file, $filename);
                    $workers_json = read_file_contents($filename);
                    unlock_file($file);
                    $workers_arr = json_decode($workers_json, true);

                    foreach ($workers_arr['workers'] as $key => $entry) {
                        if ($entry['hostname'] == $hostname) {
                            $worker_info = $workers_arr['workers'][$key];
                            break;
                        }
                    }
                }
                
                // send json response
                if ($worker_info) {
                    echo json_response(200, array('data' => $worker_info));
                } else {
                    echo json_response(200, array('data' => []));
                }
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

            // =============== TASKS API END ===============

        default:
            $data = [
                'version' => 'diskover REST API v' . $GLOBALS["API_VER"],
                'message' => 'endpoint not found'
            ];
            echo json_response(200, $data, true);
    }
}

function delete($endpoint, $input)
{
    global $client, $mnclient, $ldaplogin, $ldapadmin;

    // deny access for non-admin ldap user
    if ($ldaplogin && !$ldapadmin) {
        header('WWW-Authenticate: Basic realm="diskover REST API"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Access Denied! diskover LDAP admin group membership required for DELETE.';
        exit;
    }

    switch ($endpoint) {
        case $endpoint[0] == 'deletetask':
            try {
                if (empty($input["name"]) && empty($input["id"])) {
                    throw new ValidationError(json_encode('"name" or "id" is required'));
                }

                $filename = 'tasks/tasks.json';
                $file = fopen($filename, 'r');
                lock_file($file, $filename);
                $tasks_json = read_file_contents($filename);
                $tasks_arr = array();
                $tasks_arr = json_decode($tasks_json, true);

                $i = 0;
                $new_tasks = array();
                while($i < count($tasks_arr['tasks'])) {
                    if (isset($input["id"])) {
                        if ($tasks_arr['tasks'][$i]['id'] != $input['id']) {
                            array_push($new_tasks, $tasks_arr['tasks'][$i]);
                        }
                    } else {
                        if ($tasks_arr['tasks'][$i]['name'] != $input['name']) {
                            array_push($new_tasks, $tasks_arr['tasks'][$i]);
                        }
                    }
                    $i++;
                }
                if ($new_tasks == $tasks_arr['tasks']) {
                    if (isset($input["id"])) {
                        $desc = 'id of "'. $input["id"].'"';
                    } else {
                        $desc = 'name of "'. $input["name"].'"';
                    }
                    throw new Exception(json_encode('No task found with '. $desc ));
                }

                $tasks_arr['tasks'] = $new_tasks;

                $updated_tasks_json = json_encode($tasks_arr, JSON_PRETTY_PRINT);
                unlock_file($file);

                write_file_contents($filename, $updated_tasks_json);

                // send json response
                echo json_response(200, 'task deleted');
            } catch (ValidationError $ex) {
                echo json_response(422, '' . $ex);
            } catch (Exception $ex) {
                echo json_response(400, 'api error ' . $ex);
            }
            break;

        default:
                echo json_response(400, 'unknown api endpoint');
    }
}
