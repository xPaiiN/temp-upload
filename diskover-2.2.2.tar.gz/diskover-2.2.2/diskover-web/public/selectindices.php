<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';
require "../src/diskover/Auth.php";
require "../src/diskover/Diskover.php";

# default max index age
$maxage_default = "all";
if (isset($_GET['maxage'])) {
    $maxage_str = $_GET['maxage'];
} else {
    $maxage_str = $maxage_default;
}

// check if select indices form submitted and set cookies for indices and paths, etc
if (isset($_POST['index'])) {
    $indexselected = implode(",", $_POST['index']);
    createCookie('index', $indexselected);

    if (isset($_POST['index2'])) {
        $index2selected = $_POST['index2'];
        createCookie('index2', $_POST['index2']);
    } elseif (!isset($_POST['index2']) || $_POST['index2'] == "") {
        $index2selected = "";
        deleteCookie('index2');
    }

    clearPaths();

    // set usecache to false (flush chart cache)
    createCookie('usecache', 0);

    // delete existing sort cookies
    deleteCookie('sort');
    deleteCookie('sortorder');
    deleteCookie('sort2');
    deleteCookie('sortorder2');

    // create cookies for default search sort
    createCookie('sort', 'parent_path');
    createCookie('sortorder', 'asc');
    createCookie('sort2', 'name');
    createCookie('sortorder2', 'asc');

    // reload same page
    header("location: selectindices.php?index=" . $indexselected . "&index2=" . $index2selected . "&saved=true");
    exit();
}
// check if delete indices form is submitted
elseif (isset($_POST['delindices'])) {
    foreach ($_POST['delindices_arr'] as $k => $i) {
        if (!in_array($i, explode(',', $esIndex)) && $i != $esIndex2) {
            $delclient = $mnclient->getClientByIndex($i);
            try {
                $response = $delclient->indices()->delete(array('index' => $i));
                removeIndex(null, $i, null);
            } catch (Exception $e) {
                handleError('ES error: ' . $e->getMessage(), true);
            }
            
            $deleted = true;
        } else {
            $deleted = false;
        }
    }
    if ($deleted) {
        $del_message = "Selected indices removed!";
        $del_warning = false;
    } else {
        $del_message = "Some indices could not be removed since they are in use.";
        $del_warning = true;
    }
}
// check if index alias form is submitted
elseif (isset($_POST['aliasindices']) && !empty($_POST['aliasname'])) {
    if (isset($_POST['aliasadd'])) {
        $action = "add";
        $alias_message = "Indices added to alias.";
    } elseif (isset($_POST['aliasremove'])) {
        $action = "remove";
        $alias_message = "Indices removed from alias.";
    }
    foreach ($_POST['aliasindices_arr'] as $k => $i) {
        $params['body'] = [ 'actions' => [] ];
        if ($action == 'add') {
            $params['body']['actions'][] = [
                'add' => [
                    'index' => $i,
                    'alias' => $_POST['aliasname']
                ]
            ];
        } else {
            $params['body']['actions'][] = [
                'remove' => [
                    'index' => $i,
                    'alias' => $_POST['aliasname']
                ]
            ];
        }
        $updateclient = $mnclient->getClientByIndex($i);
        try {
            $updateclient->indices()->updateAliases($params);
        } catch (Exception $e) {
            handleError('ES error: ' . $e->getMessage(), true);
        }
        unset($params);
    }
}

// check if force delete index button is pressed
if (isset($_GET['forcedelindex'])) {
    $delclient = $mnclient->getClientByIndex($_GET['forcedelindex']);
    try {
        $response = $delclient->indices()->delete(array('index' => $_GET['forcedelindex']));
        removeIndex(null, $_GET['forcedelindex'], null);
    } catch (Exception $e) {
        handleError('ES error: ' . $e->getMessage(), true);
    }
    $del_message = "Index removed!";
    $del_warning = false;
}

// check if new indices selected or no index selected
if (isset($_GET['saved'])) {
    $save_message = 'Index selection saved!';
} elseif (isset($_GET['noindex'])) {
    $noindex_message = 'No index selected. Select an index and click save selection.';
}


// get additional index info for index table and filter indices that are displayed

$disabled_indices = array();
$indices_filtered = array();
$index_aliases = array();

// go through each index and determine which are done indexing
foreach ($es_index_info as $esnode => $esindices) {
    foreach ($esindices as $key => $val) {
        // check if index not in all_index_info
        if (!array_key_exists($key, $all_index_info)) {
            continue;
        }
        
        if (!empty($val['aliases'])) {
            $index_aliases[$key] = array();
            foreach ($val['aliases'] as $k => $v) {
                $index_aliases[$key][] = $k;
            }
        }

        // continue if index creation time is older than max age
        if ($maxage_str != 'all') {
            $starttime = $all_index_info[$key]['latest_start_at'];
            $maxage = gmdate("Y-m-d\TH:i:s", strtotime($maxage_str));
            if ($maxage > $starttime) {
                continue;
            }
        }

        // continue if index name does not match
        if (isset($_GET['namecontains']) && $_GET['namecontains'] != '') {
            if (strpos($key, $_GET['namecontains']) === false) {
                continue;
            }
        }

        // add to disabled indices and continue if index has not been refreshed (es index refresh time)
        if (!array_key_exists('crawltime', $all_index_info[$key]['totals'])) {
            $disabled_indices[] = $key;
            continue;
        }

        $indices_filtered[] = $key;

        // determine which paths if any in the index are still being crawled
        // if all the paths in the index are still being indexed, add the index to disabled_indices list
        $pathsfinished = 0;
        foreach ($all_index_info[$key] as $k => $v) {
            if ($k == 'totals' || $k == 'latest_start_at' || $k == 'hostname' || $k == 'finished') {
                continue;
            }
            if (isset($v['end_at'])) {
                // Set the path finished to true
                $all_index_info[$key][$k]['finished'] = true;
                $pathsfinished += 1;
                // Set the index finished to true
                $all_index_info[$key]['finished'] = true;
            } else {
                $all_index_info[$key][$k]['end_at'] = null;
                
                // Calculate crawl time
                $diff = abs(strtotime($v['start_at']) - strtotime(gmdate("Y-m-d\TH:i:s")));
                $all_index_info[$key][$k]['crawl_time'] = $diff;

                // Set the path finished to false
                $all_index_info[$key][$k]['finished'] = false;

                // Set the index finished to false
                $all_index_info[$key]['finished'] = false;

                // Add to index totals
                $all_index_info[$key]['totals']['crawltime'] += $all_index_info[$key][$k]['crawl_time'];
            }
            # add index to disabled_indices list if no paths in the index are finished crawling
            if ($pathsfinished == 0) {
                $disabled_indices[] = $key;
            }
        }
    }
}

$estime = number_format(microtime(true) - $_SERVER["REQUEST_TIME_FLOAT"], 4);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($_COOKIE['sendanondata']) && $_COOKIE['sendanondata'] == 1) { ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-NDFBQ1BYMH"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-NDFBQ1BYMH');
    </script>
    <?php } ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>diskover &mdash; Indices</title>
    <link rel="stylesheet" href="css/fontawesome-free/css/all.min.css" media="screen" />
    <link rel="stylesheet" href="css/bootswatch.min.css" media="screen" />
    <link rel="stylesheet" href="css/diskover.css" media="screen" />
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css" media="screen" />
    <link rel="icon" type="image/png" href="images/diskoverfavico.png" />
</head>

<body>
    <?php include "nav.php"; ?>

    <div class="container-fluid" id="mainwindow" style="margin-top:70px">
        <?php
        if (isset($save_message)) {
            echo '<div class="row"><div class="col-lg-6"><div class="alert alert-dismissible alert-success">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>' . $save_message . '</strong></div></div></div>';
        } elseif (isset($noindex_message)) {
            echo '<div class="row"><div class="col-lg-6"><div class="alert alert-dismissible alert-info">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong><i class="fas fa-bell"></i> ' . $noindex_message . '</strong></div></div></div>';
        } elseif (isset($del_message)) {
            $class = ($del_warning) ? "alert-warning" : "alert-success";
            echo '<div class="row"><div class="col-lg-6"><div class="alert alert-dismissible ' . $class . '">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>' . $del_message . '</strong> <a href="selectindices.php?maxage=' . $maxage_str . '&namecontains=' . $_GET['namecontains'] . '&reloadindices" class="alert-link">Reload indices</a>. Reloading in 3 seconds.</div></div></div>
            <script type="text/javascript">
            setTimeout(function(){
                window.location.href = "selectindices.php?maxage=' . $maxage_str . '&namecontains=' . $_GET['namecontains'] . '&reloadindices";
            }, 3000);
            </script>';
        } elseif (isset($alias_message)) {
            echo '<div class="row"><div class="col-lg-6"><div class="alert alert-dismissible alert-success">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>' . $alias_message . '</strong> <a href="selectindices.php?maxage=' . $maxage_str . '&namecontains=' . $_GET['namecontains'] . '&reloadindices" class="alert-link">Reload indices</a>. Reloading in 3 seconds.</div></div></div>
            <script type="text/javascript">
            setTimeout(function(){
                document.location.href = "selectindices.php?maxage=' . $maxage_str . '&namecontains=' . $_GET['namecontains'] . '&reloadindices";
            }, 3000);
            </script>';
        }
        ?>
        <h1 class="page-header">Indices</h1>
        <div class="row">
            <div class="col-lg-6">
                <div class="alert alert-dismissible alert-info">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <i class="glyphicon glyphicon-info-sign"></i> Please select at least one index. By default, indices are sorted by crawl finish time. <?php echo ($_SESSION['license']['product_code'] == 'ESS') ? '<br><span class="label label-info" style="border:1px solid white">Pro</span>' : ''; ?> Indices in Index 2 column are optional to select and are a previous index used for data comparison.
                    When selecting more than one index from Index column, you cannot select an index from Index 2 column.
                </div>
            </div>
            <div class="col-lg-6">
                <div class="alert alert-dismissible alert-info">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <i class="fas fa-lightbulb"></i> PRO tip: Selecting multiple indices in Index column allows you to search across more than one index and quickly switch (using nav change path dropdown <i class="far fa-hdd"></i>) between index top paths for analytics and dashboard pages.
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
            <div class="well well-sm">
                <div class="row">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get" class="form-horizontal" name="form-maxindex" id="form-maxindex">
                        <input type="hidden" name="reloadindices" value="true">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="maxindex" class="col-lg-3 control-label">Max indices to load:</label>
                                <div class="col-lg-2">
                                    <input class="form-control input-sm" name="maxindex" id="maxindex" value="<?php echo (isset($_GET['maxindex'])) ? $_GET['maxindex'] : getCookie('maxindex'); ?>">
                                </div>
                                <div class="col-lg-1">
                                    <button type="submit" id="maxindexsavebutton" class="btn btn-primary btn-sm" onclick="setCookie('maxindex', $('#maxindex').val())">Save</button>
                                </div>
                                <div class="col-lg-6">
                                    <span class="small" style="padding-left:5px"><i class="fas fa-info-circle"></i> Total <?php echo $mnclient->getTotalIndices(); ?> indices, indices are loaded in order by creation date. Max index is not used when use latest indices is checked.</span>
                                </div>
                            </div>
                        </div>
                        </form>
                        <?php if ($GLOBALS['config']->LATEST_INDEX_ENABLED) { ?>
                        <div class="col-lg-6">
                            <div class="col-lg-5">
                                <label for="uselatestindices" class="control-label">Always use latest indices (auto select)</label>
                                <input type="checkbox" name="uselatestindices" id="uselatestindices" onclick="useLatestIndices()" <?php echo (getCookie('uselatestindices') == 1) ? 'checked' : ''; ?>>
                                <span id="uselatestload" style="display:none"><img width="24" height="24" src="images/ajax-loader.gif" alt="Loading..." /></span>
                            </div>
                            <div class="col-lg-6">
                                <span class="small" style="padding-left:5px"><i class="fas fa-info-circle"></i> The latest index for each top path will be selected. Uncheck for manual index selection.</span>
                            </div>
                        </div>
                        <?php } ?>
                </div>
            </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="well well-sm">
                    <div class="row">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get" class="form-horizontal" name="form-indexfilter">
                            <div class="col-lg-5">
                                <div class="form-group">
                                    <label for="maxage" class="col-lg-6 control-label">Show indices newer than:</label>
                                    <div class="col-lg-4">
                                        <select class="form-control input-sm" name="maxage" id="maxage">
                                            <option value="all" <?php echo $maxage_str == 'all' ? 'selected="selected"' : ''; ?>>All</option>
                                            <option value="- 1 year" <?php echo $maxage_str == '- 1 year' ? 'selected="selected"' : ''; ?>>1 year</option>
                                            <option value="- 6 months" <?php echo $maxage_str == '- 6 months' ? 'selected="selected"' : ''; ?>>6 months</option>
                                            <option value="- 3 months" <?php echo $maxage_str == '- 3 months' ? 'selected="selected"' : ''; ?>>3 months</option>
                                            <option value="- 1 month" <?php echo $maxage_str == '- 1 month' ? 'selected="selected"' : ''; ?>>1 month</option>
                                            <option value="- 2 weeks" <?php echo $maxage_str == '- 2 weeks' ? 'selected="selected"' : ''; ?>>2 weeks</option>
                                            <option value="- 1 week" <?php echo $maxage_str == '- 1 week' ? 'selected="selected"' : ''; ?>>1 week</option>
                                            <option value="- 2 days" <?php echo $maxage_str == '- 2 days' ? 'selected="selected"' : ''; ?>>2 days</option>
                                            <option value="- 1 day" <?php echo $maxage_str == '- 1 day' ? 'selected="selected"' : ''; ?>>1 day</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="form-group">
                                    <label for="namecontains" class="col-lg-5 control-label">Index name contains:</label>
                                    <div class="col-lg-7">
                                        <input class="form-control input-sm" name="namecontains" id="namecontains" value="<?php echo htmlspecialchars($_GET['namecontains']); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2">
                                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Go</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php if (empty($indices_filtered)) { ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="alert alert-dismissible alert-warning">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <i class="glyphicon glyphicon-exclamation-sign"></i> No diskover indices found in Elasticsearch or index mappings are enabled and all indices are not visible. Try setting show indices to All or <a class="alert-link" href="selectindices.php?maxage=<?php echo $maxage_str ?>&namecontains=<?php echo htmlspecialchars($_GET['namecontains']) ?>&reloadindices">reload indices</a>.
                    </div>
                </div>
            </div>
        <?php } else { ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group">
                        <button type="button" class="btn btn-default" id="selectallbutton" onclick="checkIndexCheckboxes(); addHidden(); countSelected()"><i class="far fa-check-square"></i> Select all</button>
                        <button type="button" class="btn btn-default" id="unselectallbutton" onclick="clearIndexCheckboxes(); addHidden(); countSelected()"><i class="far fa-square"></i> Unselect all</button>
                        <button type="button" class="btn btn-primary" id="savebutton" onclick="checkSelectedIndex()"><i class="glyphicon glyphicon-saved"></i> Save selection</button>
                        <span style="position:absolute; top:8px; margin-left:6px" id="numindicesselectedtop"></span>
                        <button title="reload indices and refresh list" type="button" class="btn btn-default pull-right" id="reloadindices" onclick="$('#reloadindicesload').show(); window.location.replace('selectindices.php?maxage=<?php echo $maxage_str ?>&namecontains=<?php echo htmlspecialchars($_GET['namecontains']) ?>&reloadindices&refreshindices')"><i class="fas fa-sync-alt"></i> Reload indices</button>
                        <span id="reloadindicesload" style="position:relative; display:none; top:6px; padding-right:5px" class="pull-right"><img width="24" height="24" src="images/ajax-loader.gif" alt="Loading..." /></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <p class="pull-right"><?php echo count($indices_filtered) . " indices found"; ?> (last updated <?php echo $indexinfo_updatetime->format('m/d/Y, h:i:s A T'); ?> <a href="selectindices.php?maxage=<?php echo $maxage_str ?>&namecontains=<?php echo htmlspecialchars($_GET['namecontains']) ?>&reloadindices">update</a>)</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" name="form-selectindex" id="form-selectindex">
                        <table class="table table-striped table-hover table-condensed" id="indices-table" data-order='[[ <?php echo ($_SESSION['license']['product_code'] === 'ESS') ? 4 : 5; ?>, "desc" ]]' style="width:100%">
                            <thead>
                                <tr>
                                    <th>Index</th>
                                    <?php if ($_SESSION['license']['product_code'] !== 'ESS') { ?>
                                    <th>Index 2</th>
                                    <?php } ?>
                                    <th>Index Name</th>
                                    <th>Top Path(s)</th>
                                    <th>Start Time</th>
                                    <th>Finish Time</th>
                                    <th>Crawl Time</th>
                                    <th>Files</th>
                                    <th>Folders</th>
                                    <th>Inodes/sec</th>
                                    <th>File Size</th>
                                    <th>Index Size</th>
                                    <th>Pri</th>
                                    <th>Rep</th>
                                    <?php if ($_SESSION['license']['product_code'] !== 'ESS') { ?>
                                    <th>Alias</th>
                                    <?php } ?>
                                    <th>Crawl Host</th>
                                    <?php if (sizeof($config->ES_HOSTS) > 1) { ?>
                                        <th>ES Host</th>
                                    <?php } ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (!empty($indices_filtered)) {
                                    $index = getCookie('index');
                                    $index_arr = explode(',', $index);
                                    $index2 = getCookie('index2');
                                    foreach ($indices_filtered as $key => $val) {
                                        $newest = ($val == $latest_completed_index) ? "<i title=\"newest\" style=\"color:#FFF\" class=\"glyphicon glyphicon-calendar\"></i>" : "";
                                        $checked = (in_array($val, $index_arr)) ? 'checked' : '';
                                        $checked2 = ($val == $index2) ? 'checked' : '';
                                        $disabled = (in_array($val, $disabled_indices)) ? true : false;
                                        // hide indexing from non-admin users
                                        if (!$adminuser && $disabled) continue;
                                        $indexpaths = array();
                                        $starttimes = array();
                                        $finishtimes = array();
                                        $filecounts = array();
                                        $dircounts = array();
                                        $crawltimes = array();
                                        $filesizes = array();
                                        $inodespersec = array();
                                        $multipath = (sizeof($all_index_info[$val]) > 5) ? true : false;
                                        // alias check
                                        if (!empty($index_aliases)) {
                                            if (array_key_exists($val, $index_aliases)) {
                                                $alias = 'yes';
                                            } else {
                                                $alias = 'no';
                                            }
                                        } else {
                                            $alias = 'no';
                                        }
                                        $totals = array();
                                        $eshost = $mnclient->getIndexNode($val);
                                        $pri = $es_index_info[$eshost][$val]['pri_shards'];
                                        $rep = $es_index_info[$eshost][$val]['rep_shards'];

                                        echo "<tr>
                                        <td>";
                                        if (!$disabled) {
                                            echo "<input onclick=\"count(); toggleHiddenInput(this); countSelected()\" type=\"checkbox\" name=\"index[]\" id=\"index_" . $val . "\" class=\"indexcheck\" value=\"" . $val . "\" $checked></td>";
                                        } elseif ($adminuser) {
                                            echo "<a href=\"#\" title=\"force delete\" onclick=\"checkForceIndexDel('" . $val . "'); return false;\" class=\"btn btn-xs btn-primary\"><i class=\"far fa-trash-alt\"></i>";
                                        }
                                        if ($_SESSION['license']['product_code'] !== 'ESS') {
                                            echo "<td>";
                                            if (!$disabled) {
                                                echo "<input onclick=\"count2(this)\" type=\"checkbox\" name=\"index2\" id=\"index2_" . $val . "\" class=\"index2check\" value=\"" . $val . "\" $checked2></td>";
                                            }
                                        }
                                        echo "<td>" . $val . " " . $newest . "</td>";

                                        foreach ($all_index_info[$val] as $indexpathkey => $indexpathval) {
                                            if ($indexpathkey == 'totals' || $indexpathkey == 'latest_start_at' || 
                                            $indexpathkey == 'hostname' || $indexpathkey == 'finished') {
                                                continue;
                                            }
                                            $indexpaths[] = $indexpathkey;
                                            $starttimes[] = utcTimeToLocal($indexpathval['start_at']);
                                            $finishtimes[] = (is_null($indexpathval['end_at'])) ? "<span style=\"color:white\"><i class=\"fas fa-sync-alt\"></i> indexing...</span>" : utcTimeToLocal($indexpathval['end_at']);
                                            $filecounts[] = (is_null($indexpathval['file_count'])) ? "-" : number_format($indexpathval['file_count']);
                                            $dircounts[] = (is_null($indexpathval['dir_count'])) ? "-" : number_format($indexpathval['dir_count']);
                                            $crawltimes[] = (is_null($indexpathval['crawl_time'])) ?: secondsToTime($indexpathval['crawl_time']);

                                            $filesizes[] = (is_null($indexpathval['file_size'])) ? "-" : formatBytes($indexpathval['file_size']);
                                            
                                            // calc inodes/s
                                            $inodespersec[] = (is_null($indexpathval['file_count'])) ? "-" : number_format(($indexpathval['file_count'] + $indexpathval['dir_count']) / $indexpathval['crawl_time'], 1);
                                        }

                                        $totals[] = (!$all_index_info[$val]['finished']) ? "<br><span style=\"color:white;\">(" . number_format($es_index_info[$eshost][$val]['docs_count']) . " docs, " . number_format($es_index_info[$eshost][$val]['docs_count'] / $all_index_info[$val]['totals']['crawltime'], 1) . " docs/s)</span>" : "";
                                        $totals[] = ($multipath && !$disabled) ? "<br><b>" . secondsToTime($all_index_info[$val]['totals']['crawltime']) . "</b>" : "";
                                        $totals[] = ($multipath && !$disabled) ? "<br><b>" . number_format($all_index_info[$val]['totals']['filecount']) . "</b>" : "";
                                        $totals[] = ($multipath && !$disabled) ? "<br><b>" . number_format($all_index_info[$val]['totals']['dircount']) . "</b>" : "";
                                        $totals[] = ($multipath && !$disabled) ? "<br><b>" . formatBytes($all_index_info[$val]['totals']['filesize']) . "</b>" : "";

                                        $crawlhost = $all_index_info[$val]['hostname'];

                                        $indexhost = (sizeof($config->ES_HOSTS) > 1) ? '<td class="text-muted">'. $eshost .'</td>' : '';
                                        echo "<td>" . implode('<br>', $indexpaths) . "</td>
                                        <td class=\"text-muted\">" . implode('<br>', $starttimes) . "</td>
                                        <td class=\"text-muted\">" . implode('<br>', $finishtimes) . $totals[0] . "</td>
                                        <td class=\"text-muted\">" . implode('<br>', $crawltimes) . $totals[1] . "</td>
                                        <td class=\"text-muted\">" . implode('<br>', $filecounts) . $totals[2] . "</td>
                                        <td class=\"text-muted\">" . implode('<br>', $dircounts) . $totals[3] . "</td>
                                        <td class=\"text-muted\">" . implode('<br>', $inodespersec) . "</td>
                                        <td class=\"text-muted\">" . implode('<br>', $filesizes) . $totals[4] . "</td>
                                        <td class=\"text-muted\">" . formatBytes($all_index_info[$val]['totals']['indexsize']) . "</td>
                                        <td class=\"text-muted\">" . $pri . "</td>
                                        <td class=\"text-muted\">" . $rep . "</td>";
                                        if ($_SESSION['license']['product_code'] !== 'ESS') {
                                            echo "<td class=\"text-muted\">" . $alias . "</td>";
                                        }
                                        echo "<td class=\"text-muted\">" . $crawlhost . "</td>";
                                        echo $indexhost . "
                                        </tr>";
                                    }
                                }
                                // list aliases
                                if ($_SESSION['license']['product_code'] !== 'ESS') {
                                    if (!empty($index_aliases)) {
                                        $aliases_arr = array();
                                        foreach ($index_aliases as $k => $v) {
                                            foreach ($v as $key => $val) {
                                                if (in_array($val, $aliases_arr)) continue;
                                                $aliases_arr[] = $val;
                                                $checked = (in_array($val, $index_arr)) ? 'checked' : '';
                                                $checked2 = ($val == $index2) ? 'checked' : '';
                                                echo "<tr>
                                                <td><input onclick=\"count(); toggleHiddenInput(this); countSelected()\" type=\"checkbox\" name=\"index[]\" id=\"index_" . $val . "\" class=\"indexcheck\" value=\"" . $val . "\" $checked></td>";
                                                echo "<td><input onclick=\"count2(this)\" type=\"checkbox\" name=\"index2\" id=\"index2_" . $val . "\" class=\"index2check\" value=\"" . $val . "\" $checked2></td>";
                                                echo "<td>" . $val . " <i title=\"alias\" class=\"fas fa-link\" style=\"color:#FFF\"></i></td>";
                                                echo "<td></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo "<td class=\"text-muted\"></td>";
                                                echo (sizeof($config->ES_HOSTS) > 1) ? '<td class="text-muted"></td>' : '';
                                                echo "</tr>";
                                            }
                                        }
                                    }
                                }
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Index</th>
                                    <?php if ($_SESSION['license']['product_code'] !== 'ESS') { ?>
                                    <th>Index 2</th>
                                    <?php } ?>
                                    <th>Index Name</th>
                                    <th>Top Path(s)</th>
                                    <th>Start Time</th>
                                    <th>Finish Time</th>
                                    <th>Crawl Time</th>
                                    <th>Files</th>
                                    <th>Folders</th>
                                    <th>Inodes/sec</th>
                                    <th>File Size</th>
                                    <th>Index Size</th>
                                    <th>Pri</th>
                                    <th>Rep</th>
                                    <?php if ($_SESSION['license']['product_code'] !== 'ESS') { ?>
                                    <th>Alias</th>
                                    <?php } ?>
                                    <th>Crawl Host</th>
                                    <?php if (sizeof($config->ES_HOSTS) > 1) { ?>
                                        <th>ES Host</th>
                                    <?php } ?>
                                </tr>
                            </tfoot>
                        </table>
                    </form>
                    <p class="pull-right"><?php echo count($indices_filtered) . " indices found"; ?> (last updated <?php echo $indexinfo_updatetime->format('m/d/Y, h:i:s A T'); ?> <a href="selectindices.php?maxage=<?php echo $maxage_str ?>&namecontains=<?php echo htmlspecialchars($_GET['namecontains']) ?>&reloadindices">update</a>)</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group">
                        <button type="button" class="btn btn-default" id="selectallbutton2" onclick="checkIndexCheckboxes(); addHidden(); countSelected()"><i class="far fa-check-square"></i> Select all</button>
                        <button type="button" class="btn btn-default" id="unselectallbutton2" onclick="clearIndexCheckboxes(); addHidden(); countSelected()"><i class="far fa-square"></i> Unselect all</button>
                        <button type="button" class="btn btn-primary" id="savebutton2" onclick="checkSelectedIndex()"><i class="glyphicon glyphicon-saved"></i> Save selection</button>
                        <span id="numindicesselectedbottom" style="position:absolute; top:8px; margin-left:6px"></span>
                    </div>
                </div>
            </div>
            <?php if ($adminuser) { ?>
                <div class="row">
                    <div class="col-lg-6">
                        <form name="form-deleteindex" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" id="form-deleteindex">
                            <input type="hidden" name="delindices" id="delindices" value="">
                            <button type="button" class="btn btn-primary" id="deletebutton" onclick="checkIndexDel()"><i class="far fa-trash-alt"></i> Delete</button>
                        </form>
                    </div>
                </div><br />
            <?php } ?>
        <?php } ?>
        <?php if ($adminuser && !empty($indices_filtered && getCookie('uselatestindices') != 1)) { ?>
            <hr />
            <div class="row">
                <div class="col-lg-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title">Index aliases <?php echo ($_SESSION['license']['product_code'] == 'ESS') ? '<span class="label label-info">Pro</span>' : ''; ?></h3>
                        </div>
                        <div class="panel-body">
                            <p><i class="glyphicon glyphicon-info-sign"></i> To add or remove an alias from an index, select indices in the Index column and enter in the alias name below. Aliases are removed when there are no indices with the alias name. Aliases across remote clusters is not supported.</p>
                            <h4>Aliases</h4>
                            <?php
                            if (empty($index_aliases)) {
                                echo "No aliases.";
                            } else {
                                foreach ($index_aliases as $key => $val) {
                                    $aliases = "";
                                    foreach ($val as $v) {
                                        $aliases .= $v . " ";
                                    }
                                    echo $aliases . " <i class=\"fas fa-arrow-right\" style=\"color:#FFF\"></i> " . $key . "<br>\n";
                                }
                            } ?>
                            <h4>Add/remove indices</h4>
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" name="form-indexalias" id="form-indexalias" onsubmit="return checkIndexAlias()">
                                <input type="hidden" name="aliasindices" id="aliasindices" value="">
                                <fieldset>
                                    <div class="form-group">
                                        <input name="aliasname" id="aliasname" autocomplete="off" value="" type="text" placeholder="diskover-alias_name" class="form-control" <?php echo ($_SESSION['license']['product_code'] == 'ESS') ? 'title="Pro version required" disabled' : ''; ?> />
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="aliasadd" id="aliasadd" class="btn btn-primary" <?php echo ($_SESSION['license']['product_code'] == 'ESS') ? 'title="Pro version required" disabled' : ''; ?>><i class="glyphicon glyphicon-saved"></i> Add</button>
                                        <button type="submit" name="aliasremove" id="aliasremove" class="btn btn-primary" <?php echo ($_SESSION['license']['product_code'] == 'ESS') ? 'title="Pro version required" disabled' : ''; ?>><i class="glyphicon glyphicon-remove"></i> Remove</button>
                                    </div>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="pull-right small text-primary">
                    <?php
                    $time = number_format(microtime(true) - $_SERVER["REQUEST_TIME_FLOAT"], 4);
                    echo "ES Time: {$estime}, Page Load Time: {$time}";
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script language="javascript" src="js/jquery.min.js"></script>
    <script language="javascript" src="js/bootstrap.min.js"></script>
    <script language="javascript" src="js/diskover.js"></script>
    <script language="javascript" src="js/jquery.dataTables.min.js"></script>
    <script language="javascript" src="js/dataTables.bootstrap.min.js"></script>
    <script language="javascript" src="js/file-size.js"></script>
    <script language="javascript" src="js/time-elapsed-dhms.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            count();
            addHidden();
            checkSelected();
            countSelected();

            <?php if ($config->LATEST_INDEX_ENABLED) { ?>
                latestIndicesDisableCheckboxes();
                latestIndicesDisableButtons();
            <?php } ?>

            // license check
            // DO NOT ALTER, REMOVE THIS CODE OR COMMENT IT OUT.
            // REMOVING THE LICENSE CHECK VIOLATES THE LICENSE AGREEMENT AND IS AN ILLEGAL OFFENCE.
            if (product_code === 'ESS') {
                disableIndex2Checkboxes();
            }
            // end license check

            // make data table
            if (product_code === 'ESS') {
                var file_size_targets = [9, 10];
                var time_elapased_targets = [5];
                var no_orderable_targets = [0]
            } else {
                var file_size_targets = [10, 11];
                var time_elapased_targets = [6];
                var no_orderable_targets = [0, 1]
            }
            $("#indices-table").DataTable({
                "stateSave": true,
                "lengthMenu": [10, 25, 50, 75, 100],
                "pageLength": 25,
                "columnDefs": [{
                        "type": "file-size",
                        targets: file_size_targets
                    },
                    {
                        "type": "time-elapsed-dhms",
                        targets: time_elapased_targets
                    },
                    {
                        "orderable": false,
                        targets: no_orderable_targets
                    }
                ],
            });
        });
        // log indexinfo time to console
        console.log('indexinfotime: <?php echo $indexinfotime; ?> ms');
    </script>
</body>

</html>