<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';

if ($config->OAUTH2_API_TYPE == 'Okta') {
    require 'Okta.php';
} elseif ($config->OAUTH2_API_TYPE == 'Azure') {
    require 'Azure.php';
} else {
    die('Error, invalid OAUTH2_API_TYPE config setting.');
}

function start_oauth_flow()
{
    global $config;

    // Generate a random state parameter for CSRF security
    $_SESSION['oauth_state'] = bin2hex(random_bytes(10));

    // Create the PKCE code verifier and code challenge
    $_SESSION['oauth_code_verifier'] = bin2hex(random_bytes(50));
    $hash = hash('sha256', $_SESSION['oauth_code_verifier'], true);
    $code_challenge = rtrim(strtr(base64_encode($hash), '+/', '-_'), '=');

    // Build the authorization URL by starting with the authorization endpoint
    $authorization_endpoint = $config->OAUTH2_AUTH_ENDPOINT;
    $authorize_url = $authorization_endpoint . '?' . http_build_query([
        'response_type' => 'code',
        'client_id' => $config->OAUTH2_CLIENT_ID,
        'state' => $_SESSION['oauth_state'],
        'redirect_uri' => $config->OAUTH2_REDIRECT_URI,
        'code_challenge' => $code_challenge,
        'code_challenge_method' => 'S256',
        'scope' => 'openid profile email',
    ]);

    header('Location: ' . $authorize_url);
    exit;
}

function authorization_code_callback_handler()
{
    global $config;

    if (empty($_GET['state']) || $_GET['state'] != $_SESSION['oauth_state']) {
        throw new Exception("state does not match");
    }

    if (!empty($_GET['error'])) {
        throw new Exception("authorization server returned an error: " . $_GET['error']);
    }

    if (empty($_GET['code'])) {
        throw new Exception("this is unexpected, the authorization server redirected without a code or an  error");
    }

    // Exchange the authorization code for an access token by making a request to the token endpoint
    $token_endpoint = $config->OAUTH2_TOKEN_ENDPOINT;

    $ch = curl_init($token_endpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'authorization_code',
        'code' => $_GET['code'],
        'code_verifier' => $_SESSION['oauth_code_verifier'],
        'redirect_uri' => $config->OAUTH2_REDIRECT_URI,
        'client_id' => $config->OAUTH2_CLIENT_ID,
        'client_secret' => $config->OAUTH2_CLIENT_SECRET,
    ]));
    $response = json_decode(curl_exec($ch), true);

    if (isset($response['error'])) {
        throw new Exception("token endpoint returned an error: " . $response['error']);
    }

    if (!isset($response['access_token'])) {
        throw new Exception("token endpoint did not return an error or an access token");
    }

    // Save the tokens in the session
    $_SESSION['oauth2_access_token'] = $response['access_token'];

    if (isset($response['refresh_token']))
        $_SESSION['oauth2_refresh_token'] = $response['refresh_token'];

    if (isset($response['id_token']))
        $_SESSION['oauth2_id_token'] = $response['id_token'];

    login();
}

function login()
{
    global $config;

    $claims = json_decode(base64_decode(explode('.', $_SESSION['oauth2_id_token'])[1]), true);
    $username = $claims['email'] ?? $claims['preferred_username'];

    $_SESSION['stayloggedin'] = false;
    $_SESSION['loggedin'] = true;
    $_SESSION['last_activity'] = time();
    $_SESSION['oauth2login'] = true;
    fillUserDetails($username);

    if ($config->LOGINPAGE == 'dashboard') {
        header("location: index.php");
    } else {
        header("location: search.php?submitted=true&p=1&q=&loginsearch=true");
    }
    exit;
}

function logout($id_token)
{
    $logout_endpoint = $GLOBALS['config']->OAUTH2_LOGOUT_ENDPOINT;
    $logout_redirect_uri = $GLOBALS['config']->OAUTH2_LOGOUT_REDIRECT_URI;
    header("location: $logout_endpoint?id_token_hint=$id_token&post_logout_redirect_uri=$logout_redirect_uri");
    exit;
}

function apiGet($url)
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: SSWS ' . $GLOBALS['config']->OAUTH2_API_TOKEN
    ]);
    return curl_exec($ch);
}