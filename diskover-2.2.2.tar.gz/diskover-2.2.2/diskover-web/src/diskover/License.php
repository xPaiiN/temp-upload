<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/


diskover-web License helper

************************************************************************************
DO NOT ALTER, REMOVE THIS CODE OR COMMENT IT OUT.
REMOVING THE LICENSE CHECK VIOLATES THE LICENSE AGREEMENT AND IS AN ILLEGAL OFFENCE.
************************************************************************************
*/

namespace diskover;
use DateTime;
use DateTimeZone;
use diskover\Config;
use Elasticsearch\ClientBuilder;
use Elasticsearch\Common\Exceptions\NoNodesAvailableException;


class License
{
    public $lic_file;
    public $licfile_pem;
    public $license_email;
    public $validity_period;
    public $product_name;
    public $product_code;
    public $lic_es_nodes;
    public $lic_hardware_id;
    public $license_key;
    public $license_signature;
    public $hardware_id;
    public $data;
    public $config;

    public function __construct() {
        $cfg_obj = new Config();
        $config = $cfg_obj->getConfig();
        $this->config = $config;
    }
    
    public function get_lic_file()
    {
        if (strpos($_SERVER['REQUEST_URI'], 'tasks/') == true || 
            strpos($_SERVER['REQUEST_URI'], 'fileactions/') == true) {
            $licfile = "../../src/diskover/diskover-web.lic";
        } else {
            $licfile = "../src/diskover/diskover-web.lic";
        }
        if (file_exists($licfile)) {
            return $licfile;
        } else {
            die("Can't find $licfile, check license file exists.");
        }
    }

    public function get_pem_file()
    {
        if (strpos($_SERVER['REQUEST_URI'], 'tasks/') == true || 
            strpos($_SERVER['REQUEST_URI'], 'fileactions/') == true) {
            $licfile_pem = "../../src/diskover/diskover-web_publickey.pem";
        } else {
            $licfile_pem = "../src/diskover/diskover-web_publickey.pem";
        }
        if (file_exists($licfile_pem)) {
            return $licfile_pem;
        } else {
            die("Can't find $licfile_pem, check file exists.");
        }
    }

    public function is_expired()
    {
        if ($this->days_remaining() == 0) {
            return true;
        }
        return false;
    }
        
    public function days_remaining()
    {
        $today = new DateTime('today midnight', new DateTimeZone($this->config->TIMEZONE));
        $expiry_date = $this->expiry_date();
        $interval = $today->diff($expiry_date);
        $days_remain = (int)$interval->format("%r%a");
        if ($days_remain < 0) {
            $days_remain = 0;
        }
        if ($days_remain < 15 && $days_remain > 0) {
            error_log("WARNING diskover-web license expires in $days_remain days.");
        } elseif ($days_remain == 0) {
            error_log("WARNING diskover-web license expired.");
        }
        return $days_remain;
    }
    
    public function expiry_date()
    {
        return $this->validity_period;
    }

    public function check_license()
    {
        if (!isset($_COOKIE['licensecheck']) || !isset($_SESSION['license'])) {
            $this->lic_file = $this->get_lic_file();
            $this->licfile_pem = $this->get_pem_file();
            $this->hardware_id = $this->gen_hw_id();

            // check lic key
            try {
                $filestring = file_get_contents($this->lic_file);
                $licdata = explode("\n", $filestring);
                $this->license_email = $licdata[0];
                $this->validity_period = new DateTime($licdata[1], new DateTimeZone($this->config->TIMEZONE));
                $this->product_name = $licdata[2];
                $this->product_code = $licdata[3];
                $this->lic_es_nodes = $licdata[4];
                $this->lic_hardware_id = $licdata[5];
                $this->license_key = $licdata[6];
                $this->license_signature = base64_decode($this->license_key);
                $this->data = $this->license_email . $licdata[1] . $this->product_code . 
                    $this->lic_es_nodes . $this->hardware_id;
            } catch (\Exception $e) {
                die('Error reading diskover-web.lic license file. Error: '.$e->getMessage());
            }

            // check if expired
            if ($this->is_expired()) {
                die('License has expired, contact Diskover to obtain new license.');
            }

            // check hardware id in license file matches hardware id
            if ($this->hardware_id !== $this->lic_hardware_id) {
                echo "License file hardware id does not match hardware id, contact Diskover to obtain new license.<br>\n";
                echo "License file hw id:<br>\n";
                echo $this->lic_hardware_id . "<br>\n";
                echo "Hardware id:<br>\n";
                echo $this->hardware_id . "<br>\n";
                die;
            }

            $pubkey = openssl_get_publickey(file_get_contents($this->licfile_pem));
            if (openssl_verify($this->data, $this->license_signature, $pubkey, OPENSSL_ALGO_SHA1) !== 1) {
                die('Invalid license key, check diskover-web.lic for valid license. (Error: ' . openssl_error_string() . ')');
            }

            // check config settings
            $this->config_check();

            // set session vars
            $_SESSION['license'] = array();
            $_SESSION['license']['email'] = $this->license_email;
            $_SESSION['license']['validity_period'] = $this->validity_period;
            $_SESSION['license']['product_name'] = $this->product_name;
            $_SESSION['license']['product_code'] = $this->product_code;
            $_SESSION['license']['es_nodes'] = $this->lic_es_nodes;
            $_SESSION['license']['hardware_id'] = $this->lic_hardware_id;
            $_SESSION['license']['days_remaining'] = $this->days_remaining();

            // set license check cookie to expire in 1 hour
            setcookie('licensecheck', 1, time() + 3600, '/');
            // set product code cookie to expire in 1 hour
            setcookie('productcode', $this->product_code, time() + 3600, '/');
        }
    }

    public function config_check()
    {
        // check if remote clusters
        if (count($this->config->ES_HOSTS) > 1 && ($this->product_code == 'ESS' || $this->product_code == 'PRO')) {
            die('Remote clusters is unlicensed.');
        }
        // check index security
        if ($this->config->INDEX_MAPPINGS_ENABLED && $this->product_code == 'ESS') {
            die('Group/user index mappings is unlicensed.');
        }
        // check ad/ldap group filtering
        if ($this->config->LDAP_FILTERING_ENABLED && $this->product_code == 'ESS') {
            die('AD/ldap group permission filtering is unlicensed.');
        }
        // check oauth2 group filtering
        if ($this->config->OAUTH2_FILTERING_ENABLED && $this->product_code == 'ESS') {
            die('Oauth2 group permission filtering is unlicensed.');
        }
        // check Oauth2 logins
        if ($this->config->OAUTH2_LOGINS && $this->product_code == 'ESS') {
            die('Oauth2 OIDC SSO logins is unlicensed.');
        }
    }

    public function feature_check()
    {
        /*
        features license check
        */
        if (strpos($_SERVER['REQUEST_URI'], 'heatmap.php') && $_SESSION['license']['product_code'] == 'ESS') {
            die('The heatmap feature is unlicensed.');
        }
        if ((strpos($_SERVER['REQUEST_URI'], 'costanalysis.php') || strpos($_SERVER['REQUEST_URI'], 'editcost.php')) && $_SESSION['license']['product_code'] == 'ESS') {
            die('The cost analysis feature is unlicensed.');
        }
        if ((strpos($_SERVER['REQUEST_URI'], 'tags.php') || strpos($_SERVER['REQUEST_URI'], 'edittags.php')) && $_SESSION['license']['product_code'] == 'ESS') {
            die('The tags feature is unlicensed.');
        }
        if ((strpos($_SERVER['REQUEST_URI'], 'reports.php') || strpos($_SERVER['REQUEST_URI'], 'editreports.php')) && $_SESSION['license']['product_code'] == 'ESS') {
            die('The reports feature is unlicensed.');
        }
        if (strpos($_SERVER['REQUEST_URI'], 'editindexmappings.php') && $_SESSION['license']['product_code'] == 'ESS') {
            die('The index mappings feature is unlicensed.');
        }
    }

    public function file_action_check()
    {
        /*
        file actions license check
        */
        if (strpos($_SERVER['REQUEST_URI'], 'glim.php') && $_SESSION['license']['product_code'] != 'ME') {
            die('The glim file action is unlicensed.');
        }
        if (strpos($_SERVER['REQUEST_URI'], 'vantageproxyjob.php') && $_SESSION['license']['product_code'] != 'ME') {
            die('The vantage file action is unlicensed.');
        }
        if (strpos($_SERVER['REQUEST_URI'], 'filesequence.php') && $_SESSION['license']['product_code'] != 'ME') {
            die('The file sequence file action is unlicensed.');
        }
    }

    public function gen_hw_id()
    {
        /*
        generate hardware id
        hash elasticsearch cluster uuid (unique id)
        */
        $eshost = $GLOBALS['config']->ES_HOSTS[0];
        $hosts = array();
        $hosts[] = array(
            'host' => $eshost['hosts'][0], 'port' => $eshost['port'],
            'user' => $eshost['user'], 'pass' => $eshost['pass']
        );
        if ($eshost['https']) {
            $hosts[0]['scheme'] = 'https';
        }
        if (!$GLOBALS['config']->ES_SSLVERIFICATION) {
            $client = ClientBuilder::create()->setHosts($hosts)->setSSLVerification(false)->build();
        } else {
            $client = ClientBuilder::create()->setHosts($hosts)->build();
        }
        try {
            $es_cluster_uuid = $client->info()['cluster_uuid'];
        } catch (NoNodesAvailableException $e) {
            echo 'Error: No alive Elasticsearch nodes';
            exit;
        }
        return md5($es_cluster_uuid);
    }
}