<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';


function fillUserDetails($username)
{
    global $config;

    getGraphToken();

    $userData = json_decode(findUser(['email' => $username]), true);
    $userId = $userData['id'];

    $oauth2_admin = false;
    $oauth2_taskpanel_access = false;
    $userGroups = json_decode(getUserGroups($userId), true);
    $groupList = [];
    foreach ($userGroups['value'] as $group) {
        $groupName = $group['displayName'];
        $groupList[$group['id']] = $groupName;
        if (in_array($groupName, $config->OAUTH2_ADMIN_GROUPS)) {
            $oauth2_admin = true;
        }
        if (in_array($group, $config->OAUTH2_TASK_PANEL_GROUPS)) {
            $oauth2_taskpanel_access = true;
        }
    }

    $userRoles = json_decode(getUserRoles($userId), true);
    $roleList = [];
    foreach ($userRoles['value'] as $role) {
        $roleList[$role['resourceId']] = $role['resourceDisplayName'];
    }

    $_SESSION['username'] = $username;
    $_SESSION['oauth2id'] = $userId;
    $_SESSION['oauth2groups'] = $groupList;
    $_SESSION['oauth2roles'] = $roleList;
    $_SESSION['oauth2admin'] = $oauth2_admin;
    $_SESSION['oauth2taskpanel'] = $oauth2_taskpanel_access;
    $_SESSION['ldaplogin'] = false;
}

function findUser($input)
{
    $url = $GLOBALS['config']->OAUTH2_API_URL_BASE . 'users/' . urlencode($input['email']);
    return graphApiGet($url);
}

function getUserGroups($userId)
{
    $url = $GLOBALS['config']->OAUTH2_API_URL_BASE . 'users/' . $userId . '/memberOf';
    return graphApiGet($url);
}

function getUserRoles($userId)
{
    $url = $GLOBALS['config']->OAUTH2_API_URL_BASE . 'users/' . $userId . '/appRoleAssignments';
    return graphApiGet($url);
}

function getGraphToken()
{
    global $config;
        
    // Exchange the authorization code for an access token by making a request to the token endpoint
    $token_endpoint = $config->OAUTH2_TOKEN_ENDPOINT;

    $ch = curl_init($token_endpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'client_id' => $config->OAUTH2_CLIENT_ID,
        'client_secret' => $config->OAUTH2_CLIENT_SECRET,
        'scope' => 'https://graph.microsoft.com/.default',
        'grant_type' => 'client_credentials',
    ]));
    $response = json_decode(curl_exec($ch), true);

    if (isset($response['error'])) {
        throw new Exception("graph token endpoint returned an error: " . $response['error']);
    }

    if (!isset($response['access_token'])) {
        throw new Exception("graph token endpoint did not return an error or an access token");
    }

    // Save the Graph tokens in the session
    $_SESSION['oauth2_graph_access_token'] = $response['access_token'];
}

function graphApiGet($url)
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Bearer ' . $_SESSION['oauth2_graph_access_token']
    ]);
    return curl_exec($ch);
}