<?php
/*
diskover-web
https://diskoverdata.com

Copyright 2017-2023 Diskover Data, Inc.
"Community" portion of Diskover made available under the Apache 2.0 License found here:
https://www.diskoverdata.com/apache-license/
 
All other content is subject to the Diskover Data, Inc. end user license agreement found at:
https://www.diskoverdata.com/eula-subscriptions/
  
Diskover Data products and features for all versions found here:
https://www.diskoverdata.com/solutions/

*/

require '../vendor/autoload.php';


function fillUserDetails($username)
{
    global $config;

    $userData = json_decode(findUser(['email' => $username]), true);
    $userId = $userData[0]['id'];

    $oauth2_admin = false;
    $oauth2_taskpanel_access = false;
    $userGroups = json_decode(getUserGroups($userId), true);
    $groupList = [];
    foreach ($userGroups as $group) {
        $groupName = $group['profile']['name'];
        $groupList[$group['id']] = $groupName;
        if (in_array($groupName, $config->OAUTH2_ADMIN_GROUPS)) {
            $oauth2_admin = true;
        }
        if (in_array($group, $config->OAUTH2_TASK_PANEL_GROUPS)) {
            $oauth2_taskpanel_access = true;
        }
    }

    $userRoles = json_decode(getUserRoles($userId), true);
    $roleList = [];
    foreach ($userRoles as $role) {
        $roleList[$role['id']] = $role['type'];
    }

    $_SESSION['username'] = $username;
    $_SESSION['oauth2id'] = $userId;
    $_SESSION['oauth2groups'] = $groupList;
    $_SESSION['oauth2roles'] = $roleList;
    $_SESSION['oauth2admin'] = $oauth2_admin;
    $_SESSION['oauth2taskpanel'] = $oauth2_taskpanel_access;
    $_SESSION['ldaplogin'] = false;
}

function findUser($input)
{
    $url = $GLOBALS['config']->OAUTH2_API_URL_BASE . 'users?q=' . urlencode($input['email']) . '&limit=1';
    return apiGet($url);
}

function getUserGroups($userId)
{
    $url = $GLOBALS['config']->OAUTH2_API_URL_BASE . 'users/' . $userId . '/groups';
    return apiGet($url);
}

function getUserRoles($userId)
{
    $url = $GLOBALS['config']->OAUTH2_API_URL_BASE . 'users/' . $userId . '/roles';
    return apiGet($url);
}